#!/usr/bin/env python3
"""
Patch: change_routes.py
Fixes:
  1. reject_change() - broken indentation (status check unreachable)
  2. Dead code after cancel_scheduled_change (orphaned lines)
  3. create_resolution_request - missing status check
"""
import sys

filepath = "/opt/opsis/backend/api/change_routes.py"

with open(filepath, 'r') as f:
    content = f.read()

errors = []

# ============================================================================
# FIX 1: reject_change - Fix broken indentation
# The status check is indented under the 404 if-block, making it unreachable.
# Also the function is split by dead code from cancel_scheduled_change.
# ============================================================================

# The broken pattern: missing status check + orphaned code
old_reject = '''    if not change:
        raise HTTPException(status_code=404, detail="Change request not found")

        raise HTTPException(
            status_code=400,
            detail=f"Cannot reject change with status '{change.status}'"
        )

    change.status = "rejected"
    change.rejection_reason = reason
    change.updated_at = datetime.now(timezone.utc)

    db.commit()'''

new_reject = '''    if not change:
        raise HTTPException(status_code=404, detail="Change request not found")

    if change.status != "pending":
        raise HTTPException(
            status_code=400,
            detail=f"Cannot reject change with status '{change.status}'"
        )

    change.status = "rejected"
    change.rejection_reason = reason
    change.updated_at = datetime.now(timezone.utc)

    db.commit()'''

if old_reject in content:
    content = content.replace(old_reject, new_reject, 1)
    print("✅ Fixed reject_change() - corrected indentation of status check")
else:
    errors.append("❌ Could not find reject_change broken indentation pattern")

# ============================================================================
# FIX 2: Remove orphaned dead code after cancel_scheduled_change
# There are two blocks of orphaned code:
#   1. "    db.refresh(change)\n\n    logger.info(f"Change {change_id} rejected..."
#   2. Duplicate "if deleted_count > 0:" block
# ============================================================================

# Remove the orphaned reject code that appears after cancel_scheduled_change
old_orphan = '''    return change

    db.refresh(change)

    logger.info(f"Change {change_id} rejected by user {current_user.id}: {reason}")

    return change


@router.post("/{change_id}/execute", response_model=ExecutionResponse)'''

new_orphan = '''    return change


@router.post("/{change_id}/execute", response_model=ExecutionResponse)'''

if old_orphan in content:
    content = content.replace(old_orphan, new_orphan, 1)
    print("✅ Removed orphaned dead code after cancel_scheduled_change")
else:
    errors.append("❌ Could not find orphaned dead code pattern after cancel_scheduled_change")

# ============================================================================
# FIX 3: Remove duplicate "if deleted_count > 0" block in analyze_environment
# ============================================================================

old_dup_commit = '''    if deleted_count > 0:
        db.commit()
        logger.info(f"Removed {deleted_count} duplicate change requests")

    if deleted_count > 0:
        db.commit()
        logger.info(f"Removed {deleted_count} duplicate change requests")'''

new_dup_commit = '''    if deleted_count > 0:
        db.commit()
        logger.info(f"Removed {deleted_count} duplicate change requests")'''

if old_dup_commit in content:
    content = content.replace(old_dup_commit, new_dup_commit, 1)
    print("✅ Removed duplicate 'if deleted_count' block in analyze_environment")
else:
    errors.append("⚠️  Could not find duplicate deleted_count pattern (may already be fixed)")

# ============================================================================
# FIX 4: create_resolution_request - missing status check
# ============================================================================

old_resolution_check = '''    if not change:
        raise HTTPException(status_code=404, detail="Change request not found")

        raise HTTPException(status_code=400, detail="Only failed changes can have resolution requests")'''

new_resolution_check = '''    if not change:
        raise HTTPException(status_code=404, detail="Change request not found")

    if change.status != "failed":
        raise HTTPException(status_code=400, detail="Only failed changes can have resolution requests")'''

if old_resolution_check in content:
    content = content.replace(old_resolution_check, new_resolution_check, 1)
    print("✅ Fixed create_resolution_request - added status check")
else:
    errors.append("⚠️  Could not find create_resolution_request broken pattern")

# ============================================================================
# FIX 5: Remove duplicate field declarations in ChangeRequestResponse
# ============================================================================

old_dup_fields = '''    portal_url: Optional[str] = None
    is_manual: bool = False
    portal_url: Optional[str] = None
    is_manual: bool = False'''

new_dup_fields = '''    portal_url: Optional[str] = None
    is_manual: bool = False'''

if old_dup_fields in content:
    content = content.replace(old_dup_fields, new_dup_fields, 1)
    print("✅ Removed duplicate fields in ChangeRequestResponse")
else:
    errors.append("⚠️  Could not find duplicate ChangeRequestResponse fields")

# ============================================================================
# Write patched file
# ============================================================================

critical_errors = [e for e in errors if e.startswith("❌")]

if critical_errors:
    print("\n⚠️  Critical patches could not be applied:")
    for e in errors:
        print(f"  {e}")
    print("\nFile was NOT modified. Fix manually.")
    sys.exit(1)
else:
    with open(filepath, 'w') as f:
        f.write(content)
    if errors:
        print("\n⚠️  Non-critical warnings:")
        for e in errors:
            print(f"  {e}")
    print(f"\n✅ All critical patches applied to {filepath}")
