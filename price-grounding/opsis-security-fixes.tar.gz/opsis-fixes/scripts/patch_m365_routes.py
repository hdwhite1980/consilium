#!/usr/bin/env python3
"""
Patch: m365_routes.py
Fixes:
  1. list_tenants() - no org scoping (multi-tenant data leak)
  2. connect_tenant() - plaintext azure_client_secret storage
"""
import sys

filepath = "/opt/opsis/backend/api/m365_routes.py"

with open(filepath, 'r') as f:
    content = f.read()

errors = []

# ============================================================================
# FIX 1: list_tenants - Add org scoping
# ============================================================================

old_list_tenants = '''def list_tenants(
    client_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """List connected M365 tenants"""

    query = db.query(M365Tenant)

    if client_id:
        query = query.filter(M365Tenant.client_id == client_id)

    return query.all()'''

new_list_tenants = '''def list_tenants(
    client_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """List connected M365 tenants (scoped to user's organization)"""
    from models.client import Client

    # FIX: Scope to user's organization to prevent multi-tenant data leak
    query = db.query(M365Tenant).join(
        Client, M365Tenant.client_id == Client.id
    ).filter(
        Client.organization_id == current_user.organization_id
    )

    if client_id:
        query = query.filter(M365Tenant.client_id == client_id)

    return query.all()'''

if old_list_tenants in content:
    content = content.replace(old_list_tenants, new_list_tenants)
    print("✅ Fixed list_tenants() - added org scoping")
else:
    errors.append("❌ Could not find list_tenants() pattern - manual fix needed")

# ============================================================================
# FIX 2: connect_tenant - Encrypt azure_client_secret before storing
# ============================================================================

# Fix the success path
old_tenant_create_success = '''        tenant = M365Tenant(
            client_id=client_id,
            tenant_id=tenant_data.tenant_id,
            azure_client_id=tenant_data.azure_client_id,
            azure_client_secret=tenant_data.azure_client_secret,
            status=M365ConnectionStatus.CONNECTED
        )'''

new_tenant_create_success = '''        tenant = M365Tenant(
            client_id=client_id,
            tenant_id=tenant_data.tenant_id,
            azure_client_id=tenant_data.azure_client_id,
            azure_client_secret=encrypt_secret(tenant_data.azure_client_secret),
            status=M365ConnectionStatus.CONNECTED
        )'''

if old_tenant_create_success in content:
    content = content.replace(old_tenant_create_success, new_tenant_create_success, 1)
    print("✅ Fixed connect_tenant() success path - encrypting client_secret")
else:
    errors.append("❌ Could not find connect_tenant success tenant creation pattern")

# Fix the error path
old_tenant_create_error = '''        tenant = M365Tenant(
            client_id=client_id,
            tenant_id=tenant_data.tenant_id,
            azure_client_id=tenant_data.azure_client_id,
            azure_client_secret=tenant_data.azure_client_secret,
            status=M365ConnectionStatus.ERROR,
            error_message=str(e)
        )'''

new_tenant_create_error = '''        tenant = M365Tenant(
            client_id=client_id,
            tenant_id=tenant_data.tenant_id,
            azure_client_id=tenant_data.azure_client_id,
            azure_client_secret=encrypt_secret(tenant_data.azure_client_secret),
            status=M365ConnectionStatus.ERROR,
            error_message=str(e)
        )'''

if old_tenant_create_error in content:
    content = content.replace(old_tenant_create_error, new_tenant_create_error, 1)
    print("✅ Fixed connect_tenant() error path - encrypting client_secret")
else:
    errors.append("❌ Could not find connect_tenant error tenant creation pattern")

# ============================================================================
# Write patched file
# ============================================================================

if errors:
    print("\n⚠️  Some patches could not be applied:")
    for e in errors:
        print(f"  {e}")
    print("\nFile was NOT modified. Fix manually.")
    sys.exit(1)
else:
    with open(filepath, 'w') as f:
        f.write(content)
    print(f"\n✅ All patches applied to {filepath}")
