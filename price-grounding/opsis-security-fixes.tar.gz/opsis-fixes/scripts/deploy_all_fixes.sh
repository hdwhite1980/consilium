#!/bin/bash
# ============================================================================
# OPSIS Security Fix Deployment Script
# Date: 2026-02-16
# Fixes: 14 issues from Batch 1 & 2 audit
# ============================================================================
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "============================================"
echo " OPSIS Security Fix Deployment"
echo " $(date)"
echo "============================================"
echo ""

BACKEND="/opt/opsis/backend"
BACKUP_DIR="/opt/opsis/backup_$(date +%Y%m%d_%H%M%S)"
CONTAINER="opsis-backend"

# ============================================================================
# STEP 1: Backup current files
# ============================================================================
echo -e "${YELLOW}[1/5] Creating backup...${NC}"
mkdir -p "$BACKUP_DIR/api"
cp "$BACKEND/api/client_routes.py" "$BACKUP_DIR/api/"
cp "$BACKEND/api/client_management_routes.py" "$BACKUP_DIR/api/"
cp "$BACKEND/api/ticket_routes.py" "$BACKUP_DIR/api/"
cp "$BACKEND/api/m365_routes.py" "$BACKUP_DIR/api/"
cp "$BACKEND/api/change_routes.py" "$BACKUP_DIR/api/"
cp "$BACKEND/api/schedule_routes.py" "$BACKUP_DIR/api/"
echo -e "${GREEN}  Backup saved to $BACKUP_DIR${NC}"

# ============================================================================
# STEP 2: Deploy full file replacements
# ============================================================================
echo ""
echo -e "${YELLOW}[2/5] Deploying patched files...${NC}"

# These files are complete replacements (small enough to verify fully)
cp /tmp/opsis-fixes/backend/client_routes.py "$BACKEND/api/client_routes.py"
echo -e "${GREEN}  ✅ client_routes.py - org scoping + permission checks${NC}"

cp /tmp/opsis-fixes/backend/client_management_routes.py "$BACKEND/api/client_management_routes.py"
echo -e "${GREEN}  ✅ client_management_routes.py - NameError fix + duplicate decorator${NC}"

cp /tmp/opsis-fixes/backend/ticket_routes.py "$BACKEND/api/ticket_routes.py"
echo -e "${GREEN}  ✅ ticket_routes.py - org scoping + background task session fix${NC}"

cp /tmp/opsis-fixes/backend/schedule_routes.py "$BACKEND/api/schedule_routes.py"
echo -e "${GREEN}  ✅ schedule_routes.py - org scoping via tenant->client join${NC}"

# ============================================================================
# STEP 3: Run targeted patch scripts for large files
# ============================================================================
echo ""
echo -e "${YELLOW}[3/5] Running targeted patches...${NC}"

python3 /tmp/opsis-fixes/scripts/patch_m365_routes.py
echo ""
python3 /tmp/opsis-fixes/scripts/patch_change_routes.py

# ============================================================================
# STEP 4: Deploy to Docker container
# ============================================================================
echo ""
echo -e "${YELLOW}[4/5] Deploying to Docker container...${NC}"

docker cp "$BACKEND/api/client_routes.py" "$CONTAINER:/app/api/client_routes.py"
docker cp "$BACKEND/api/client_management_routes.py" "$CONTAINER:/app/api/client_management_routes.py"
docker cp "$BACKEND/api/ticket_routes.py" "$CONTAINER:/app/api/ticket_routes.py"
docker cp "$BACKEND/api/m365_routes.py" "$CONTAINER:/app/api/m365_routes.py"
docker cp "$BACKEND/api/change_routes.py" "$CONTAINER:/app/api/change_routes.py"
docker cp "$BACKEND/api/schedule_routes.py" "$CONTAINER:/app/api/schedule_routes.py"
echo -e "${GREEN}  All files copied to container${NC}"

# Clear __pycache__
docker exec "$CONTAINER" find /app -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
echo -e "${GREEN}  Cache cleared${NC}"

# ============================================================================
# STEP 5: Restart and verify
# ============================================================================
echo ""
echo -e "${YELLOW}[5/5] Restarting backend...${NC}"
docker restart "$CONTAINER"
sleep 5

# Quick health check
if docker exec "$CONTAINER" python -c "
import importlib
import sys
sys.path.insert(0, '/app')

# Verify each patched module imports cleanly
modules = [
    'api.client_routes',
    'api.client_management_routes',
    'api.ticket_routes',
    'api.m365_routes',
    'api.change_routes',
    'api.schedule_routes',
]
for mod in modules:
    try:
        importlib.import_module(mod)
        print(f'  ✅ {mod}')
    except Exception as e:
        print(f'  ❌ {mod}: {e}')
        sys.exit(1)
print('All modules imported successfully')
" 2>/dev/null; then
    echo -e "${GREEN}  All modules verified!${NC}"
else
    echo -e "${RED}  ⚠️  Import verification failed - check logs!${NC}"
    echo -e "${YELLOW}  To rollback: cp $BACKUP_DIR/api/* $BACKEND/api/ && deploy${NC}"
fi

echo ""
echo "============================================"
echo -e "${GREEN} Deployment complete!${NC}"
echo "============================================"
echo ""
echo "FIXES APPLIED:"
echo "  [CRITICAL] client_routes.py list_clients - org scoping added"
echo "  [CRITICAL] client_routes.py delete/api-key - permission checks added"
echo "  [CRITICAL] client_management_routes.py get_client - NameError fixed"
echo "  [CRITICAL] ticket_routes.py list_tickets - org scoping added"
echo "  [CRITICAL] m365_routes.py list_tenants - org scoping added"
echo "  [SECURITY] m365_routes.py connect_tenant - secret encryption"
echo "  [WARNING]  ticket_routes.py background task - own DB session"
echo "  [WARNING]  change_routes.py reject_change - indentation fixed"
echo "  [WARNING]  change_routes.py dead code removed"
echo "  [WARNING]  change_routes.py duplicate fields removed"
echo "  [WARNING]  change_routes.py create_resolution status check"
echo "  [WARNING]  schedule_routes.py - org scoping via tenant join"
echo ""
echo "BACKUP: $BACKUP_DIR"
echo "ROLLBACK: cp $BACKUP_DIR/api/* $BACKEND/api/"
echo "          then redeploy to container"
