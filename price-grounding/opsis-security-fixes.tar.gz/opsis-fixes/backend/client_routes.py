import logging
logger = logging.getLogger(__name__)
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from models.database import get_db
from models.client import Client, SubscriptionTier
from models.endpoint import Endpoint
from models.user import User, UserRole
from models.user_client_access import UserClientAccess
from models.user import User
from auth.dependencies import get_current_active_user

router = APIRouter(tags=["Clients"])


# ============================================================================
# HELPER: Validate user has access to a specific client
# ============================================================================

def _validate_client_access(client_id: int, current_user: User, db: Session) -> Client:
    """
    Check that the user has access to the client.
    ADMIN/ORG_ADMIN within the same org can access any of that org's clients.
    Other roles require explicit UserClientAccess entry.
    Returns the Client object or raises 403/404.
    """
    client = db.query(Client).filter(Client.id == client_id).first()
    if not client:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Client not found"
        )

    # Must be same organization
    if client.organization_id != current_user.organization_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )

    # ADMIN and ORG_ADMIN can access any client in their org
    if current_user.role in (UserRole.ADMIN, UserRole.ORG_ADMIN):
        return client

    # Other roles need explicit access
    access = db.query(UserClientAccess).filter(
        UserClientAccess.user_id == current_user.id,
        UserClientAccess.client_id == client_id
    ).first()
    if not access:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You don't have access to this client"
        )

    return client


# Request/Response Models
class ClientCreate(BaseModel):
    name: str
    company_name: Optional[str] = None
    email: EmailStr
    phone: Optional[str] = None
    subscription_tier: SubscriptionTier = SubscriptionTier.STARTER
    billing_email: Optional[str] = None
    sla_response_time_hours: int = 24
    sla_resolution_time_hours: int = 72
    industry: Optional[str] = None
    sub_industry: Optional[str] = None


class ClientUpdate(BaseModel):
    name: Optional[str] = None
    company_name: Optional[str] = None
    phone: Optional[str] = None
    subscription_tier: Optional[SubscriptionTier] = None
    is_active: Optional[bool] = None
    sla_response_time_hours: Optional[int] = None
    sla_resolution_time_hours: Optional[int] = None
    industry: Optional[str] = None
    sub_industry: Optional[str] = None


class ClientResponse(BaseModel):
    id: int
    name: str
    company_name: Optional[str]
    email: str
    phone: Optional[str]
    subscription_tier: str
    is_active: bool
    sla_response_time_hours: int
    sla_resolution_time_hours: int
    industry: Optional[str] = None
    sub_industry: Optional[str] = None
    security_template_id: Optional[int] = None
    endpoint_count: int = 0
    ticket_count: int = 0

    class Config:
        from_attributes = True


class IndustryUpdate(BaseModel):
    industry: str
    sub_industry: Optional[str] = None


# Valid industries
VALID_INDUSTRIES = [
    "healthcare", "finance", "government", "legal", "education",
    "retail", "manufacturing", "technology", "nonprofit", "general"
]


@router.post("", response_model=ClientResponse, status_code=status.HTTP_201_CREATED)
def create_client(
    client_data: ClientCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create a new client"""

    # Check if client with this email already exists
    existing = db.query(Client).filter(Client.email == client_data.email).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Client with this email already exists"
        )

    # Validate industry if provided
    if client_data.industry and client_data.industry.lower() not in VALID_INDUSTRIES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid industry. Valid options: {VALID_INDUSTRIES}"
        )

    # Create client
    data = client_data.model_dump()
    if data.get("industry"):
        data["industry"] = data["industry"].lower()
    if data.get("sub_industry"):
        data["sub_industry"] = data["sub_industry"].lower()

    # Set organization from current user
    data['organization_id'] = current_user.organization_id

    # Auto-generate API key if not provided
    if not data.get('api_key'):
        import secrets, string
        data['api_key'] = 'ops_' + ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(40))
    # Auto-generate HMAC secret for WebSocket message signing
    if not data.get('hmac_secret'):
        import secrets as _secrets
        data['hmac_secret'] = _secrets.token_hex(32)

    client = Client(**data)
    db.add(client)
    db.commit()
    db.refresh(client)

    # Auto-assign client to creating user
    from sqlalchemy import text as sa_text
    db.execute(sa_text(
        "INSERT INTO user_client_access (user_id, client_id, access_level, created_at, granted_by) "
        "VALUES (:uid, :cid, 'admin', NOW(), :uid) ON CONFLICT DO NOTHING"
    ), {"uid": current_user.id, "cid": client.id})
    # Also assign to all org admins
    db.execute(sa_text(
        "INSERT INTO user_client_access (user_id, client_id, access_level, created_at, granted_by) "
        "SELECT id, :cid, 'full', NOW(), :uid FROM users "
        "WHERE organization_id = :oid AND role = 'org_admin' AND id != :uid "
        "ON CONFLICT DO NOTHING"
    ), {"cid": client.id, "uid": current_user.id, "oid": current_user.organization_id})
    db.commit()

    # Add counts
    response = ClientResponse.model_validate(client)
    response.endpoint_count = len(client.endpoints)
    response.ticket_count = len(client.tickets)

    return response


@router.get("", response_model=List[ClientResponse])
def list_clients(
    skip: int = 0,
    limit: int = 100,
    is_active: Optional[bool] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """List all clients (scoped to user's organization)"""

    # FIX: Scope to user's organization to prevent multi-tenant data leak
    query = db.query(Client).filter(
        Client.organization_id == current_user.organization_id
    )

    if is_active is not None:
        query = query.filter(Client.is_active == is_active)

    # For non-admin roles, further scope to assigned clients only
    if current_user.role not in (UserRole.ADMIN, UserRole.ORG_ADMIN):
        accessible_ids = db.query(UserClientAccess.client_id).filter(
            UserClientAccess.user_id == current_user.id
        ).subquery()
        query = query.filter(Client.id.in_(accessible_ids))

    clients = query.offset(skip).limit(limit).all()

    # Add counts to each client
    results = []
    for client in clients:
        response = ClientResponse(
            id=client.id,
            name=client.name,
            company_name=client.company_name,
            email=client.email,
            phone=client.phone,
            subscription_tier=client.subscription_tier.value,
            is_active=client.is_active,
            sla_response_time_hours=client.sla_response_time_hours,
            sla_resolution_time_hours=client.sla_resolution_time_hours,
            industry=client.industry,
            sub_industry=client.sub_industry,
            security_template_id=client.security_template_id,
            endpoint_count=len(client.endpoints),
            ticket_count=len(client.tickets)
        )
        results.append(response)

    return results


@router.get("/{client_id}", response_model=ClientResponse)
def get_client(
    client_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get a specific client"""

    # FIX: Validate access (org scoping + role check)
    client = _validate_client_access(client_id, current_user, db)

    response = ClientResponse(
        id=client.id,
        name=client.name,
        company_name=client.company_name,
        email=client.email,
        phone=client.phone,
        subscription_tier=client.subscription_tier.value,
        is_active=client.is_active,
        sla_response_time_hours=client.sla_response_time_hours,
        sla_resolution_time_hours=client.sla_resolution_time_hours,
        industry=client.industry,
        sub_industry=client.sub_industry,
        security_template_id=client.security_template_id,
        endpoint_count=len(client.endpoints),
        ticket_count=len(client.tickets)
    )

    return response


@router.patch("/{client_id}", response_model=ClientResponse)
def update_client(
    client_id: int,
    client_data: ClientUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update a client"""

    # FIX: Validate access (org scoping + role check)
    client = _validate_client_access(client_id, current_user, db)

    # Validate industry if provided
    if client_data.industry and client_data.industry.lower() not in VALID_INDUSTRIES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid industry. Valid options: {VALID_INDUSTRIES}"
        )

    # Update fields
    update_data = client_data.model_dump(exclude_unset=True)

    # Normalize industry values
    if "industry" in update_data and update_data["industry"]:
        update_data["industry"] = update_data["industry"].lower()
        # Clear template assignment when industry changes
        client.security_template_id = None
    if "sub_industry" in update_data and update_data["sub_industry"]:
        update_data["sub_industry"] = update_data["sub_industry"].lower()

    for field, value in update_data.items():
        setattr(client, field, value)

    db.commit()
    db.refresh(client)

    response = ClientResponse(
        id=client.id,
        name=client.name,
        company_name=client.company_name,
        email=client.email,
        phone=client.phone,
        subscription_tier=client.subscription_tier.value,
        is_active=client.is_active,
        sla_response_time_hours=client.sla_response_time_hours,
        sla_resolution_time_hours=client.sla_resolution_time_hours,
        industry=client.industry,
        sub_industry=client.sub_industry,
        security_template_id=client.security_template_id,
        endpoint_count=len(client.endpoints),
        ticket_count=len(client.tickets)
    )

    return response


@router.patch("/{client_id}/industry", response_model=ClientResponse)
def update_client_industry(
    client_id: int,
    industry_data: IndustryUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update a client's industry classification - triggers template assignment"""

    # FIX: Validate access
    client = _validate_client_access(client_id, current_user, db)

    industry = industry_data.industry.lower()
    if industry not in VALID_INDUSTRIES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid industry. Valid options: {VALID_INDUSTRIES}"
        )

    # Update industry
    client.industry = industry
    client.sub_industry = industry_data.sub_industry.lower() if industry_data.sub_industry else None
    client.security_template_id = None  # Clear to trigger re-assignment

    db.commit()
    db.refresh(client)

    response = ClientResponse(
        id=client.id,
        name=client.name,
        company_name=client.company_name,
        email=client.email,
        phone=client.phone,
        subscription_tier=client.subscription_tier.value,
        is_active=client.is_active,
        sla_response_time_hours=client.sla_response_time_hours,
        sla_resolution_time_hours=client.sla_resolution_time_hours,
        industry=client.industry,
        sub_industry=client.sub_industry,
        security_template_id=client.security_template_id,
        endpoint_count=len(client.endpoints),
        ticket_count=len(client.tickets)
    )

    return response


@router.delete("/{client_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_client(
    client_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Delete a client (ORG_ADMIN only)"""

    # FIX: Require ORG_ADMIN role
    if current_user.role not in (UserRole.ADMIN, UserRole.ORG_ADMIN):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can delete clients"
        )

    # FIX: Validate access (ensures same org)
    client = _validate_client_access(client_id, current_user, db)

    db.delete(client)
    db.commit()

    return None


@router.get("/{client_id}/api-key")
def get_client_api_key(
    client_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get API key for a client (ORG_ADMIN or users with access)"""

    # FIX: Validate access (replaces TODO)
    client = _validate_client_access(client_id, current_user, db)

    return {
        "client_id": client.id,
        "client_name": client.name,
        "api_key": client.api_key,
        "tenant_id": f"client-{client.id}",
        "created_at": client.created_at,
        "billing_status": client.billing_status,
        "instructions": {
            "websocket_url": "wss://opsisapp.com/api/agent/ws/{device_id}",
            "headers_required": [
                "Authorization: Bearer {api_key}",
                "X-Tenant-ID: client-{client_id}",
                "X-Agent-Version: 1.0.0",
                "X-Agent-Machine: HOSTNAME",
                "X-Agent-OS: win32 10.0.22621"
            ]
        }
    }


@router.post("/{client_id}/api-key/regenerate")
def regenerate_client_api_key(
    client_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Regenerate API key for a client (ORG_ADMIN only)"""
    import uuid

    # FIX: Require ORG_ADMIN role (replaces TODO)
    if current_user.role not in (UserRole.ADMIN, UserRole.ORG_ADMIN):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only administrators can regenerate API keys"
        )

    # FIX: Validate access (ensures same org)
    client = _validate_client_access(client_id, current_user, db)

    # Generate new API key with grace period
    from datetime import datetime, timezone
    old_key = client.api_key
    new_key = f"opsis_{uuid.uuid4().hex}"

    client.previous_api_key = old_key
    client.key_rotated_at = datetime.now(timezone.utc)
    client.api_key = new_key
    db.commit()

    # Log the regeneration
    logger.warning(f"API key regenerated for client {client_id} ({client.name}) by user {current_user.id}")

    return {
        "client_id": client.id,
        "client_name": client.name,
        "old_key": old_key[:20] + "...",  # Masked
        "new_key": new_key,
        "warning": "All connected agents will be disconnected. Update agent configurations with new key.",
        "agents_affected": db.query(Endpoint).filter(Endpoint.client_id == client_id).count()
    }


@router.get("/{client_id}/agent-setup")
def get_client_agent_setup(
    client_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Get agent setup information for a client
    User must have access to this client via UserClientAccess
    """
    # FIX: Use unified access check
    client = _validate_client_access(client_id, current_user, db)

    # Get endpoint count
    endpoint_count = db.query(Endpoint).filter(Endpoint.client_id == client_id).count()
    active_count = db.query(Endpoint).filter(
        Endpoint.client_id == client_id,
        Endpoint.status == 'online'
    ).count()

    return {
        "client_id": client.id,
        "client_name": client.name,
        "api_key": client.api_key,
        "tenant_id": f"client-{client.id}",
        "billing_status": client.billing_status,
        "is_active": client.is_active,
        "server_config": {
            "websocket_url": "wss://opsisapp.com/api/agent/ws/{device_id}",
            "http_url": "https://opsisapp.com",
            "update_check_url": "https://opsisapp.com/api/agent/update-check"
        },
        "agent_config": {
            "serverUrl": "wss://opsisapp.com",
            "apiKey": client.api_key,
            "tenantId": f"client-{client.id}",
            "agentVersion": "1.0.0",
            "monitoring": {
                "heartbeatInterval": 30000,
                "telemetryInterval": 60000,
                "healthCheckInterval": 300000
            },
            "reconnect": {
                "enabled": True,
                "baseDelay": 1000,
                "maxDelay": 300000
            },
            "hmacSecret": client.hmac_secret or ""
        },
        "setup_headers": {
            "Authorization": f"Bearer {client.api_key}",
            "X-Tenant-ID": f"client-{client.id}",
            "X-Agent-Version": "1.0.0",
            "X-Agent-Machine": "HOSTNAME",
            "X-Agent-OS": "win32 10.0.22621"
        },
        "stats": {
            "total_endpoints": endpoint_count,
            "active_agents": active_count
        }
    }


@router.get("/{client_id}/stats")
def get_client_stats(
    client_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get statistics for a specific client"""
    from models.endpoint import Endpoint
    from models.ticket import Ticket, TicketStatus
    from models.m365 import M365Tenant
    from datetime import datetime, timedelta, timezone

    # FIX: Use unified access check
    client = _validate_client_access(client_id, current_user, db)

    # Endpoint stats
    total_endpoints = db.query(Endpoint).filter(
        Endpoint.client_id == client_id
    ).count()

    online_endpoints = db.query(Endpoint).filter(
        Endpoint.client_id == client_id,
        Endpoint.status == 'ONLINE'
    ).count()

    # Ticket stats
    open_tickets = db.query(Ticket).filter(
        Ticket.client_id == client_id,
        Ticket.status.in_([TicketStatus.NEW, TicketStatus.IN_PROGRESS])
    ).count()

    resolved_tickets_30d = db.query(Ticket).filter(
        Ticket.client_id == client_id,
        Ticket.status == TicketStatus.RESOLVED,
        Ticket.resolved_at >= datetime.now(timezone.utc) - timedelta(days=30)
    ).count()

    # M365 tenant
    m365_tenant = db.query(M365Tenant).filter(
        M365Tenant.client_id == client_id
    ).first()

    return {
        "client_id": client_id,
        "client_name": client.name,
        "endpoints": {
            "total": total_endpoints,
            "online": online_endpoints,
            "offline": total_endpoints - online_endpoints,
            "limit": client.max_endpoints or 50
        },
        "tickets": {
            "open": open_tickets,
            "resolved_30d": resolved_tickets_30d
        },
        "m365": {
            "connected": m365_tenant is not None,
            "tenant_id": m365_tenant.tenant_id if m365_tenant else None,
            "status": m365_tenant.status.value if m365_tenant and m365_tenant.status else None
        }
    }
