from datetime import datetime, timedelta, timezone
"""
Client Management Routes
For MSPs to manage their clients and for Direct Customers to view their info
"""

from typing import Optional, List
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr

from models.database import get_db
from models.user import User, UserRole
from models.organization import Organization, OrganizationType
from models.client import Client, SubscriptionTier
from models.user_client_access import UserClientAccess
from auth.dependencies import get_current_active_user, require_role, validate_client_access, get_accessible_clients
from services.audit_service import log_audit

router = APIRouter(prefix="/clients", tags=["Client Management"])


# ============================================================================
# REQUEST/RESPONSE MODELS
# ============================================================================

class ClientCreate(BaseModel):
    """Create new client (MSP only)"""
    name: str
    company_name: Optional[str] = None
    email: EmailStr
    phone: Optional[str] = None
    subscription_tier: SubscriptionTier = SubscriptionTier.STARTER
    billing_email: Optional[EmailStr] = None
    billing_address: Optional[str] = None
    sla_response_time_hours: int = 24
    sla_resolution_time_hours: int = 72
    industry: Optional[str] = None
    sub_industry: Optional[str] = None


class ClientUpdate(BaseModel):
    """Update existing client"""
    name: Optional[str] = None
    company_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    subscription_tier: Optional[SubscriptionTier] = None
    is_active: Optional[bool] = None


class ClientResponse(BaseModel):
    id: int
    organization_id: int
    name: str
    company_name: Optional[str]
    email: str
    phone: Optional[str]
    subscription_tier: str
    is_active: bool
    industry: Optional[str]
    created_at: datetime
    endpoint_count: Optional[int] = 0

    class Config:
        from_attributes = True


# ============================================================================
# LIST CLIENTS
# ============================================================================

@router.get("", response_model=List[ClientResponse])
async def list_clients(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """List all clients accessible to current user"""

    clients = get_accessible_clients(current_user, db)

    from models.endpoint import Endpoint
    response = []
    for client in clients:
        endpoint_count = db.query(Endpoint).filter(
            Endpoint.client_id == client.id
        ).count()

        client_dict = ClientResponse.from_orm(client).dict()
        client_dict['endpoint_count'] = endpoint_count
        response.append(client_dict)

    return response


# ============================================================================
# GET CLIENT DETAILS
# ============================================================================

# FIX: Removed duplicate @router.get decorator
@router.get("/{client_id}", response_model=ClientResponse)
async def get_client(
    client_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Get detailed information about a specific client"""
    # FIX: Use client_id (not client.id) since client isn't defined yet
    await validate_client_access(client_id, current_user, db)

    # Then retrieve the client object
    from models.client import Client
    client = db.query(Client).filter(Client.id == client_id).first()

    if not client:
        raise HTTPException(status_code=404, detail="Client not found")

    from models.endpoint import Endpoint
    endpoint_count = db.query(Endpoint).filter(
        Endpoint.client_id == client.id
    ).count()

    client_dict = ClientResponse.from_orm(client).dict()
    client_dict['endpoint_count'] = endpoint_count

    return client_dict


# ============================================================================
# CREATE CLIENT (MSP ONLY)
# ============================================================================

@router.post("", response_model=ClientResponse, status_code=status.HTTP_201_CREATED)
async def create_client(
    client_data: ClientCreate,
    request: Request,
    current_user: User = Depends(require_role([UserRole.ORG_ADMIN])),
    db: Session = Depends(get_db)
):
    """Create new client (MSP only)"""

    organization = db.query(Organization).filter(
        Organization.id == current_user.organization_id
    ).first()

    if organization.organization_type != OrganizationType.MSP:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only MSP organizations can create clients"
        )

    client_count = db.query(Client).filter(
        Client.organization_id == organization.id
    ).count()

    if client_count >= organization.max_clients:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Client limit reached ({organization.max_clients} clients)"
        )

    client = Client(
        organization_id=organization.id,
        name=client_data.name,
        company_name=client_data.company_name or client_data.name,
        email=client_data.email,
        phone=client_data.phone,
        subscription_tier=client_data.subscription_tier,
        billing_email=client_data.billing_email or client_data.email,
        billing_address=client_data.billing_address,
        sla_response_time_hours=client_data.sla_response_time_hours,
        sla_resolution_time_hours=client_data.sla_resolution_time_hours,
        industry=client_data.industry,
        sub_industry=client_data.sub_industry,
        is_active=True
    )

    db.add(client)
    db.commit()
    db.refresh(client)

    access = UserClientAccess(
        user_id=current_user.id,
        client_id=client.id,
        access_level="full",
        granted_by=current_user.id
    )
    db.add(access)
    db.commit()

    await log_audit(
        db=db,
        user_id=current_user.id,
        organization_id=organization.id,
        client_id=client.id,
        action="client_created",
        resource_type="client",
        resource_id=client.id,
        ip_address=request.client.host,
        details={"client_name": client.name}
    )

    return client


# ============================================================================
# UPDATE CLIENT
# ============================================================================

@router.patch("/{client_id}", response_model=ClientResponse)
async def update_client(
    client_id: int,
    client_data: ClientUpdate,
    request: Request,
    current_user: User = Depends(require_role([UserRole.ORG_ADMIN])),
    db: Session = Depends(get_db)
):
    """Update client information (ORG_ADMIN only)"""

    client = validate_client_access(client_id, current_user, db)

    update_data = client_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(client, field, value)

    db.commit()
    db.refresh(client)

    await log_audit(
        db=db,
        user_id=current_user.id,
        organization_id=current_user.organization_id,
        client_id=client.id,
        action="client_updated",
        resource_type="client",
        resource_id=client.id,
        ip_address=request.client.host,
        details={"updated_fields": list(update_data.keys())}
    )

    return client


# ============================================================================
# DELETE CLIENT
# ============================================================================

@router.delete("/{client_id}")
async def delete_client(
    client_id: int,
    request: Request,
    current_user: User = Depends(require_role([UserRole.ORG_ADMIN])),
    db: Session = Depends(get_db)
):
    """Delete client (ORG_ADMIN only, MSP only)"""

    client = validate_client_access(client_id, current_user, db)

    organization = db.query(Organization).filter(
        Organization.id == current_user.organization_id
    ).first()

    if organization.organization_type != OrganizationType.MSP:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot delete client in Direct Customer organization"
        )

    from models.endpoint import Endpoint
    endpoint_count = db.query(Endpoint).filter(
        Endpoint.client_id == client.id
    ).count()

    if endpoint_count > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot delete client with active endpoints ({endpoint_count} endpoints). Remove endpoints first."
        )

    client_name = client.name

    db.delete(client)
    db.commit()

    await log_audit(
        db=db,
        user_id=current_user.id,
        organization_id=organization.id,
        action="client_deleted",
        resource_type="client",
        resource_id=client_id,
        ip_address=request.client.host,
        details={"client_name": client_name}
    )

    return {"success": True, "message": f"Client '{client_name}' deleted"}
