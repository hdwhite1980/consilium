from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, timedelta, timezone
from models.database import get_db
from models.ticket import Ticket, TicketType, TicketPriority, TicketStatus, TicketCategory
from models.client import Client
from models.endpoint import Endpoint
from models.user import User, UserRole
from models.user_client_access import UserClientAccess
from auth.dependencies import get_current_active_user
from ai_engine.ticket_analyzer import TicketAnalyzer
from ai_engine.resolution_engine import ResolutionEngine

router = APIRouter( tags=["Tickets"])


# Request/Response Models
class TicketCreate(BaseModel):
    client_id: int
    endpoint_id: Optional[int] = None
    subject: str
    description: str
    priority: TicketPriority = TicketPriority.MEDIUM


class TicketResponse(BaseModel):
    id: int
    client_id: int
    endpoint_id: Optional[int]
    subject: str
    description: str
    ticket_type: str
    priority: str
    status: str
    category: Optional[str]
    ai_analyzed: bool
    ai_confidence: Optional[float]
    ai_root_cause: Optional[str]
    created_at: datetime
    updated_at: Optional[datetime]

    class Config:
        from_attributes = True


class AIAnalysisResponse(BaseModel):
    ticket_id: int
    analysis: dict
    confidence: float


class ResolutionResponse(BaseModel):
    ticket_id: int
    resolution: dict


def _get_accessible_client_ids(current_user: User, db: Session) -> list:
    """Get list of client IDs the current user can access."""
    if current_user.role in (UserRole.ADMIN, UserRole.ORG_ADMIN):
        # Admins can see all clients in their org
        return [c.id for c in db.query(Client.id).filter(
            Client.organization_id == current_user.organization_id
        ).all()]
    else:
        # Other roles only see assigned clients
        return [a.client_id for a in db.query(UserClientAccess.client_id).filter(
            UserClientAccess.user_id == current_user.id
        ).all()]


@router.post("", response_model=TicketResponse, status_code=status.HTTP_201_CREATED)
def create_ticket(
    ticket_data: TicketCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create a new ticket"""

    # Verify client exists and user has access
    client = db.query(Client).filter(Client.id == ticket_data.client_id).first()
    if not client:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Client not found"
        )

    # FIX: Verify user has access to this client's org
    if client.organization_id != current_user.organization_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )

    # Verify endpoint if provided
    if ticket_data.endpoint_id:
        endpoint = db.query(Endpoint).filter(Endpoint.id == ticket_data.endpoint_id).first()
        if not endpoint or endpoint.client_id != client.id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Endpoint not found or doesn't belong to this client"
            )

    # Create ticket
    ticket = Ticket(**ticket_data.model_dump())

    # Calculate SLA due dates
    ticket.sla_response_due = datetime.now(timezone.utc) + timedelta(hours=client.sla_response_time_hours)
    ticket.sla_resolution_due = datetime.now(timezone.utc) + timedelta(hours=client.sla_resolution_time_hours)

    db.add(ticket)
    db.commit()
    db.refresh(ticket)

    # FIX: Pass ticket_id instead of db session to background task
    # Background task creates its own session
    if client.ai_enabled:
        background_tasks.add_task(analyze_ticket_background, ticket.id)

    return ticket


@router.get("", response_model=List[TicketResponse])
def list_tickets(
    skip: int = 0,
    limit: int = 100,
    client_id: Optional[int] = None,
    status: Optional[TicketStatus] = None,
    priority: Optional[TicketPriority] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """List tickets with filtering (scoped to user's accessible clients)"""

    query = db.query(Ticket)

    # FIX: Scope to accessible clients to prevent multi-tenant data leak
    accessible_client_ids = _get_accessible_client_ids(current_user, db)
    query = query.filter(Ticket.client_id.in_(accessible_client_ids))

    if client_id:
        # Verify user has access to the requested client
        if client_id not in accessible_client_ids:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this client"
            )
        query = query.filter(Ticket.client_id == client_id)
    if status:
        query = query.filter(Ticket.status == status)
    if priority:
        query = query.filter(Ticket.priority == priority)

    tickets = query.order_by(Ticket.created_at.desc()).offset(skip).limit(limit).all()
    return tickets


@router.get("/{ticket_id}", response_model=TicketResponse)
def get_ticket(
    ticket_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get a specific ticket"""

    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ticket not found"
        )

    # FIX: Verify user has access to this ticket's client
    accessible_client_ids = _get_accessible_client_ids(current_user, db)
    if ticket.client_id not in accessible_client_ids:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )

    return ticket


@router.post("/{ticket_id}/analyze", response_model=AIAnalysisResponse)
async def analyze_ticket(
    ticket_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Analyze a ticket with AI"""

    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ticket not found"
        )

    # Check if client has AI enabled
    client = db.query(Client).filter(Client.id == ticket.client_id).first()
    if not client.ai_enabled:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="AI features not enabled for this client's subscription tier"
        )

    # Update status
    ticket.status = TicketStatus.ANALYZING
    db.commit()

    # Get endpoint if available
    endpoint = None
    if ticket.endpoint_id:
        endpoint = db.query(Endpoint).filter(Endpoint.id == ticket.endpoint_id).first()

    # Analyze with AI
    analyzer = TicketAnalyzer()
    analysis = await analyzer.analyze_ticket(ticket, endpoint)

    # Update ticket with analysis
    ticket.ai_analyzed = True
    ticket.ai_analysis = analysis
    ticket.ai_confidence = analysis.get("confidence", 0)
    ticket.ai_suggested_priority = analyzer.get_priority_enum(analysis.get("priority", "medium"))
    ticket.ai_suggested_category = analyzer.get_category_enum(analysis.get("category", "other"))
    ticket.ai_root_cause = analysis.get("root_cause_hypothesis", "")

    # Auto-apply suggestions if confidence is high
    if analysis.get("confidence", 0) > 75:
        ticket.priority = ticket.ai_suggested_priority
        ticket.category = ticket.ai_suggested_category

    ticket.status = TicketStatus.NEW
    db.commit()
    db.refresh(ticket)

    return {
        "ticket_id": ticket.id,
        "analysis": analysis,
        "confidence": analysis.get("confidence", 0)
    }


@router.post("/{ticket_id}/resolution", response_model=ResolutionResponse)
async def generate_resolution(
    ticket_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Generate resolution plan for a ticket"""

    ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
    if not ticket:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ticket not found"
        )

    # Check if client has AI enabled
    client = db.query(Client).filter(Client.id == ticket.client_id).first()
    if not client.ai_enabled:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="AI features not enabled for this client's subscription tier"
        )

    # Get endpoint if available
    endpoint = None
    if ticket.endpoint_id:
        endpoint = db.query(Endpoint).filter(Endpoint.id == ticket.endpoint_id).first()

    # Generate resolution
    engine = ResolutionEngine()
    resolution = await engine.generate_resolution(ticket, endpoint)

    # Save resolution to ticket
    ticket.ai_resolution_steps = resolution
    db.commit()

    return {
        "ticket_id": ticket.id,
        "resolution": resolution
    }


def analyze_ticket_background(ticket_id: int):
    """Background task to analyze ticket - creates its own DB session"""
    import asyncio
    from models.database import SessionLocal

    # FIX: Create own session instead of reusing request-scoped session
    db = SessionLocal()
    try:
        ticket = db.query(Ticket).filter(Ticket.id == ticket_id).first()
        if not ticket:
            return

        endpoint = None
        if ticket.endpoint_id:
            endpoint = db.query(Endpoint).filter(Endpoint.id == ticket.endpoint_id).first()

        analyzer = TicketAnalyzer()
        analysis = asyncio.run(analyzer.analyze_ticket(ticket, endpoint))

        ticket.ai_analyzed = True
        ticket.ai_analysis = analysis
        ticket.ai_confidence = analysis.get("confidence", 0)
        ticket.ai_root_cause = analysis.get("root_cause_hypothesis", "")

        db.commit()
    except Exception as e:
        print(f"Background ticket analysis failed for ticket {ticket_id}: {e}", flush=True)
        db.rollback()
    finally:
        db.close()
