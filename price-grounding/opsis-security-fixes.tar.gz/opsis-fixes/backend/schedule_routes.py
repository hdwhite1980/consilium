"""
OPSIS Scheduled Analysis API Routes
Manage scheduled M365 environment analysis jobs
"""

from datetime import datetime, timezone, time
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
import logging

from models.database import get_db
from models.scheduled_job import ScheduledAnalysisJob, ScheduledAnalysisHistory
from models.m365 import M365Tenant
from models.client import Client
from auth.dependencies import get_current_active_user
from models.user import User

logger = logging.getLogger(__name__)
router = APIRouter( tags=["Scheduled Analysis"])


# ==================== PYDANTIC MODELS ====================

class ScheduleCreate(BaseModel):
    tenant_id: int
    is_enabled: bool = True
    schedule_type: str = "daily"  # daily, weekly, monthly
    schedule_time: str = "06:00"  # HH:MM format
    schedule_day: int = 1  # Day of week (1=Mon) or day of month
    email_enabled: bool = True
    email_recipients: List[str] = []
    email_on_new_only: bool = True


class ScheduleUpdate(BaseModel):
    is_enabled: Optional[bool] = None
    schedule_type: Optional[str] = None
    schedule_time: Optional[str] = None
    schedule_day: Optional[int] = None
    email_enabled: Optional[bool] = None
    email_recipients: Optional[List[str]] = None
    email_on_new_only: Optional[bool] = None


class ScheduleResponse(BaseModel):
    id: int
    tenant_id: int
    tenant_name: Optional[str] = None
    is_enabled: bool
    schedule_type: str
    schedule_time: str
    schedule_day: int
    email_enabled: bool
    email_recipients: List[str]
    email_on_new_only: bool
    last_run_at: Optional[datetime]
    last_run_status: Optional[str]
    last_run_recommendations: int
    last_error: Optional[str]
    next_run_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


class HistoryResponse(BaseModel):
    id: int
    job_id: int
    tenant_id: int
    started_at: datetime
    completed_at: Optional[datetime]
    status: str
    recommendations_created: int
    recommendations_details: List[dict]
    email_sent: bool
    email_recipients: List[str]
    email_error: Optional[str]
    error_message: Optional[str]

    class Config:
        from_attributes = True


# ==================== HELPER ====================

def _get_org_tenant_ids(current_user: User, db: Session) -> list:
    """Get M365 tenant IDs accessible to the current user's organization."""
    return [t.id for t in db.query(M365Tenant.id).join(
        Client, M365Tenant.client_id == Client.id
    ).filter(
        Client.organization_id == current_user.organization_id
    ).all()]


# ==================== API ENDPOINTS ====================

@router.get("", response_model=List[ScheduleResponse])
async def list_schedules(
    tenant_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """List all scheduled analysis jobs (scoped to user's organization)"""
    query = db.query(ScheduledAnalysisJob)

    # FIX: Scope to user's org tenants
    org_tenant_ids = _get_org_tenant_ids(current_user, db)
    query = query.filter(ScheduledAnalysisJob.tenant_id.in_(org_tenant_ids))

    if tenant_id:
        if tenant_id not in org_tenant_ids:
            raise HTTPException(status_code=403, detail="Access denied to this tenant")
        query = query.filter(ScheduledAnalysisJob.tenant_id == tenant_id)

    jobs = query.all()

    # Enrich with tenant names
    result = []
    for job in jobs:
        tenant = db.query(M365Tenant).filter(M365Tenant.id == job.tenant_id).first()
        response = ScheduleResponse(
            id=job.id,
            tenant_id=job.tenant_id,
            tenant_name=tenant.tenant_id if tenant else None,
            is_enabled=job.is_enabled,
            schedule_type=job.schedule_type,
            schedule_time=job.schedule_time.strftime("%H:%M") if job.schedule_time else "06:00",
            schedule_day=job.schedule_day or 1,
            email_enabled=job.email_enabled,
            email_recipients=job.email_recipients or [],
            email_on_new_only=job.email_on_new_only,
            last_run_at=job.last_run_at,
            last_run_status=job.last_run_status,
            last_run_recommendations=job.last_run_recommendations or 0,
            last_error=job.last_error,
            next_run_at=job.next_run_at,
            created_at=job.created_at
        )
        result.append(response)

    return result


@router.get("/{schedule_id}", response_model=ScheduleResponse)
async def get_schedule(
    schedule_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get a specific scheduled job"""
    job = db.query(ScheduledAnalysisJob).filter(ScheduledAnalysisJob.id == schedule_id).first()

    if not job:
        raise HTTPException(status_code=404, detail="Schedule not found")

    # FIX: Verify org access
    org_tenant_ids = _get_org_tenant_ids(current_user, db)
    if job.tenant_id not in org_tenant_ids:
        raise HTTPException(status_code=403, detail="Access denied")

    tenant = db.query(M365Tenant).filter(M365Tenant.id == job.tenant_id).first()

    return ScheduleResponse(
        id=job.id,
        tenant_id=job.tenant_id,
        tenant_name=tenant.tenant_id if tenant else None,
        is_enabled=job.is_enabled,
        schedule_type=job.schedule_type,
        schedule_time=job.schedule_time.strftime("%H:%M") if job.schedule_time else "06:00",
        schedule_day=job.schedule_day or 1,
        email_enabled=job.email_enabled,
        email_recipients=job.email_recipients or [],
        email_on_new_only=job.email_on_new_only,
        last_run_at=job.last_run_at,
        last_run_status=job.last_run_status,
        last_run_recommendations=job.last_run_recommendations or 0,
        last_error=job.last_error,
        next_run_at=job.next_run_at,
        created_at=job.created_at
    )


@router.post("", response_model=ScheduleResponse, status_code=201)
async def create_schedule(
    schedule_data: ScheduleCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create a new scheduled analysis job"""

    # Check tenant exists
    tenant = db.query(M365Tenant).filter(M365Tenant.id == schedule_data.tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    # FIX: Verify org access
    org_tenant_ids = _get_org_tenant_ids(current_user, db)
    if schedule_data.tenant_id not in org_tenant_ids:
        raise HTTPException(status_code=403, detail="Access denied to this tenant")

    # Check if schedule already exists for this tenant
    existing = db.query(ScheduledAnalysisJob).filter(
        ScheduledAnalysisJob.tenant_id == schedule_data.tenant_id
    ).first()

    if existing:
        raise HTTPException(
            status_code=400,
            detail="Schedule already exists for this tenant. Use PUT to update."
        )

    # Parse time
    try:
        hours, minutes = map(int, schedule_data.schedule_time.split(":"))
        schedule_time = time(hours, minutes)
    except:
        schedule_time = time(6, 0)

    # Calculate next run
    from services.scheduler_service import scheduler

    job = ScheduledAnalysisJob(
        tenant_id=schedule_data.tenant_id,
        is_enabled=schedule_data.is_enabled,
        schedule_type=schedule_data.schedule_type,
        schedule_time=schedule_time,
        schedule_day=schedule_data.schedule_day,
        email_enabled=schedule_data.email_enabled,
        email_recipients=schedule_data.email_recipients,
        email_on_new_only=schedule_data.email_on_new_only
    )

    # Calculate next run time
    job.next_run_at = scheduler._calculate_next_run(job)

    db.add(job)
    db.commit()
    db.refresh(job)

    logger.info(f"Created scheduled job for tenant {schedule_data.tenant_id}")

    return ScheduleResponse(
        id=job.id,
        tenant_id=job.tenant_id,
        tenant_name=tenant.tenant_id,
        is_enabled=job.is_enabled,
        schedule_type=job.schedule_type,
        schedule_time=job.schedule_time.strftime("%H:%M"),
        schedule_day=job.schedule_day,
        email_enabled=job.email_enabled,
        email_recipients=job.email_recipients or [],
        email_on_new_only=job.email_on_new_only,
        last_run_at=job.last_run_at,
        last_run_status=job.last_run_status,
        last_run_recommendations=job.last_run_recommendations or 0,
        last_error=job.last_error,
        next_run_at=job.next_run_at,
        created_at=job.created_at
    )


@router.put("/{schedule_id}", response_model=ScheduleResponse)
async def update_schedule(
    schedule_id: int,
    schedule_data: ScheduleUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update a scheduled job"""
    job = db.query(ScheduledAnalysisJob).filter(ScheduledAnalysisJob.id == schedule_id).first()

    if not job:
        raise HTTPException(status_code=404, detail="Schedule not found")

    # FIX: Verify org access
    org_tenant_ids = _get_org_tenant_ids(current_user, db)
    if job.tenant_id not in org_tenant_ids:
        raise HTTPException(status_code=403, detail="Access denied")

    # Update fields
    if schedule_data.is_enabled is not None:
        job.is_enabled = schedule_data.is_enabled
    if schedule_data.schedule_type is not None:
        job.schedule_type = schedule_data.schedule_type
    if schedule_data.schedule_time is not None:
        try:
            hours, minutes = map(int, schedule_data.schedule_time.split(":"))
            job.schedule_time = time(hours, minutes)
        except:
            pass
    if schedule_data.schedule_day is not None:
        job.schedule_day = schedule_data.schedule_day
    if schedule_data.email_enabled is not None:
        job.email_enabled = schedule_data.email_enabled
    if schedule_data.email_recipients is not None:
        job.email_recipients = schedule_data.email_recipients
    if schedule_data.email_on_new_only is not None:
        job.email_on_new_only = schedule_data.email_on_new_only

    # Recalculate next run
    from services.scheduler_service import scheduler
    job.next_run_at = scheduler._calculate_next_run(job)
    job.updated_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(job)

    tenant = db.query(M365Tenant).filter(M365Tenant.id == job.tenant_id).first()

    logger.info(f"Updated scheduled job {schedule_id}")

    return ScheduleResponse(
        id=job.id,
        tenant_id=job.tenant_id,
        tenant_name=tenant.tenant_id if tenant else None,
        is_enabled=job.is_enabled,
        schedule_type=job.schedule_type,
        schedule_time=job.schedule_time.strftime("%H:%M") if job.schedule_time else "06:00",
        schedule_day=job.schedule_day or 1,
        email_enabled=job.email_enabled,
        email_recipients=job.email_recipients or [],
        email_on_new_only=job.email_on_new_only,
        last_run_at=job.last_run_at,
        last_run_status=job.last_run_status,
        last_run_recommendations=job.last_run_recommendations or 0,
        last_error=job.last_error,
        next_run_at=job.next_run_at,
        created_at=job.created_at
    )


@router.delete("/{schedule_id}")
async def delete_schedule(
    schedule_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Delete a scheduled job"""
    job = db.query(ScheduledAnalysisJob).filter(ScheduledAnalysisJob.id == schedule_id).first()

    if not job:
        raise HTTPException(status_code=404, detail="Schedule not found")

    # FIX: Verify org access
    org_tenant_ids = _get_org_tenant_ids(current_user, db)
    if job.tenant_id not in org_tenant_ids:
        raise HTTPException(status_code=403, detail="Access denied")

    db.delete(job)
    db.commit()

    logger.info(f"Deleted scheduled job {schedule_id}")

    return {"message": "Schedule deleted", "id": schedule_id}


@router.post("/{schedule_id}/run-now")
async def run_schedule_now(
    schedule_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Manually trigger a scheduled job to run immediately"""
    job = db.query(ScheduledAnalysisJob).filter(ScheduledAnalysisJob.id == schedule_id).first()

    if not job:
        raise HTTPException(status_code=404, detail="Schedule not found")

    # FIX: Verify org access
    org_tenant_ids = _get_org_tenant_ids(current_user, db)
    if job.tenant_id not in org_tenant_ids:
        raise HTTPException(status_code=403, detail="Access denied")

    try:
        from services.scheduler_service import scheduler
        result = await scheduler.run_now(db, job.tenant_id)

        return {
            "message": "Analysis completed",
            "status": result["status"],
            "recommendations": result["recommendations"],
            "error": result["error"]
        }
    except Exception as e:
        logger.exception(f"Failed to run scheduled analysis: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{schedule_id}/history", response_model=List[HistoryResponse])
async def get_schedule_history(
    schedule_id: int,
    limit: int = Query(20, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get execution history for a scheduled job"""
    job = db.query(ScheduledAnalysisJob).filter(ScheduledAnalysisJob.id == schedule_id).first()

    if not job:
        raise HTTPException(status_code=404, detail="Schedule not found")

    # FIX: Verify org access
    org_tenant_ids = _get_org_tenant_ids(current_user, db)
    if job.tenant_id not in org_tenant_ids:
        raise HTTPException(status_code=403, detail="Access denied")

    history = db.query(ScheduledAnalysisHistory)\
        .filter(ScheduledAnalysisHistory.job_id == schedule_id)\
        .order_by(ScheduledAnalysisHistory.started_at.desc())\
        .limit(limit)\
        .all()

    return [
        HistoryResponse(
            id=h.id,
            job_id=h.job_id,
            tenant_id=h.tenant_id,
            started_at=h.started_at,
            completed_at=h.completed_at,
            status=h.status,
            recommendations_created=h.recommendations_created or 0,
            recommendations_details=h.recommendations_details or [],
            email_sent=h.email_sent,
            email_recipients=h.email_recipients or [],
            email_error=h.email_error,
            error_message=h.error_message
        )
        for h in history
    ]


@router.post("/tenant/{tenant_id}")
async def create_or_get_schedule_for_tenant(
    tenant_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get or create a schedule for a tenant (convenience endpoint)"""

    tenant = db.query(M365Tenant).filter(M365Tenant.id == tenant_id).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    # FIX: Verify org access
    org_tenant_ids = _get_org_tenant_ids(current_user, db)
    if tenant_id not in org_tenant_ids:
        raise HTTPException(status_code=403, detail="Access denied to this tenant")

    job = db.query(ScheduledAnalysisJob).filter(
        ScheduledAnalysisJob.tenant_id == tenant_id
    ).first()

    if not job:
        # Create default schedule
        from services.scheduler_service import scheduler

        job = ScheduledAnalysisJob(
            tenant_id=tenant_id,
            is_enabled=False,  # Disabled by default
            schedule_type="daily",
            schedule_time=time(6, 0),
            schedule_day=1,
            email_enabled=False,
            email_recipients=[],
            email_on_new_only=True
        )
        job.next_run_at = scheduler._calculate_next_run(job)

        db.add(job)
        db.commit()
        db.refresh(job)

    return ScheduleResponse(
        id=job.id,
        tenant_id=job.tenant_id,
        tenant_name=tenant.tenant_id,
        is_enabled=job.is_enabled,
        schedule_type=job.schedule_type,
        schedule_time=job.schedule_time.strftime("%H:%M") if job.schedule_time else "06:00",
        schedule_day=job.schedule_day or 1,
        email_enabled=job.email_enabled,
        email_recipients=job.email_recipients or [],
        email_on_new_only=job.email_on_new_only,
        last_run_at=job.last_run_at,
        last_run_status=job.last_run_status,
        last_run_recommendations=job.last_run_recommendations or 0,
        last_error=job.last_error,
        next_run_at=job.next_run_at,
        created_at=job.created_at
    )
