#!/bin/bash
# Add server_powershell_routes to main.py router imports

FILE="/opt/opsis/backend/main.py"

# Check if already registered
if grep -q "server_powershell_routes" "$FILE"; then
    echo "✅ server_powershell_routes already registered"
    exit 0
fi

# Find the last router import line and add after it
# Look for the pattern: from api.XXX_routes import router as XXX_router
LAST_IMPORT_LINE=$(grep -n "from api\." "$FILE" | tail -1 | cut -d: -f1)

if [ -z "$LAST_IMPORT_LINE" ]; then
    echo "❌ Could not find router imports in main.py"
    exit 1
fi

# Add import after last router import
sed -i "${LAST_IMPORT_LINE}a\\from api.server_powershell_routes import router as server_powershell_router" "$FILE"

# Find where routers are included (app.include_router) and add ours
LAST_INCLUDE_LINE=$(grep -n "app.include_router" "$FILE" | tail -1 | cut -d: -f1)

if [ -z "$LAST_INCLUDE_LINE" ]; then
    echo "❌ Could not find app.include_router in main.py"
    exit 1
fi

sed -i "${LAST_INCLUDE_LINE}a\\app.include_router(server_powershell_router, prefix=\"/api\")" "$FILE"

echo "✅ server_powershell_routes registered in main.py"
echo "   Import added after line $LAST_IMPORT_LINE"
echo "   Router included after line $LAST_INCLUDE_LINE"
