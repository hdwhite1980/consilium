"""
OPSIS Server-Side PowerShell Execution API
Secured internal endpoint for N8N workflows to execute M365 PowerShell on the backend.

This is the "server-side agent" - the backend itself runs PowerShell commands
for M365 management (Exchange Online, Microsoft Graph) that can't run on
endpoint agents.

Security:
- Internal-only endpoint (not exposed to frontend)
- HMAC signature verification for N8N webhook calls
- Command allowlist for safety
- Full audit logging
- Timeout enforcement
"""

import os
import json
import hmac
import hashlib
import asyncio
import logging
import subprocess
from datetime import datetime, timezone
from typing import Optional, Dict, List
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from pydantic import BaseModel

from models.database import get_db

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/internal", tags=["Internal"])

# Shared secret for N8N → backend authentication
INTERNAL_SECRET = os.getenv("INTERNAL_API_SECRET", os.getenv("SECRET_KEY", ""))

# Maximum execution time per command (seconds)
MAX_TIMEOUT = 120

# Default timeout
DEFAULT_TIMEOUT = 30


# ============================================================
# Allowed command prefixes (safety allowlist)
# Only these PowerShell cmdlets can be executed server-side
# ============================================================

ALLOWED_CMDLET_PREFIXES = {
    # Exchange Online
    "get-mailbox", "set-mailbox", "get-mailboxpermission", "add-mailboxpermission",
    "remove-mailboxpermission", "get-recipientpermission", "add-recipientpermission",
    "remove-recipientpermission", "set-mailboxautoreplyconfiguration",
    "get-mailboxautoreplyconfiguration", "get-distributiongroup",
    "get-distributiongroupmember", "remove-distributiongroupmember",
    "add-distributiongroupmember", "get-unifiedgroup",
    "new-mailbox", "enable-mailbox",

    # Exchange Online - Teams/Groups
    "get-team", "get-teamuser", "remove-teamuser",

    # Microsoft Graph PowerShell
    "get-mguser", "update-mguser", "get-mguserauth",
    "revoke-mgsigninsession", "get-mgusermemberof",
    "remove-mggroupmember", "get-mggroup",
    "get-mguseroapermissiongrant", "remove-mguseroapermissiongrant",
    "get-mguserlicensedetail", "set-mguserlicense",
    "get-mguserauthenticationmethod",
    "remove-mguserauthenticationphonenumbermethod",
    "remove-mguserauthenticationmicrosoftauthenticatormethod",

    # SPO (SharePoint Online)
    "get-sposite", "set-spouser", "get-spouser",

    # MSOnline (legacy but installed)
    "get-msoluser", "set-msoluser", "set-msoluserpassword",
    "get-msoluserlicense", "set-msoluserlicense",

    # General safe commands
    "get-date", "write-host", "write-output",
    "connect-exchangeonline", "connect-mggraph",
    "disconnect-exchangeonline", "disconnect-mggraph",

    # Credential/connection (using cert-based auth)
    "get-credential",
}

# Explicitly blocked patterns (override allowlist)
BLOCKED_PATTERNS = {
    "remove-mailbox", "remove-mguser", "delete-mguser",
    "invoke-expression", "invoke-command", "iex",
    "start-process", "new-pssession",
    "restart-computer", "stop-computer",
    "remove-item c:\\", "remove-item /",
    "format-volume", "clear-disk",
}


class ServerPowerShellRequest(BaseModel):
    """Request to execute PowerShell on the server."""
    command: str
    timeout: int = DEFAULT_TIMEOUT
    runbook_id: Optional[int] = None
    step_index: Optional[int] = None
    workflow_id: Optional[str] = None
    context: Optional[Dict] = None  # Variables like $UPN, $ManagerEmail


class ServerPowerShellResponse(BaseModel):
    """Response from server-side PowerShell execution."""
    success: bool
    output: str
    error: Optional[str] = None
    exit_code: int = 0
    duration_ms: int = 0
    command_hash: str = ""
    executed_at: str = ""


# ============================================================
# Security helpers
# ============================================================

def verify_command_safety(command: str) -> tuple[bool, str]:
    """
    Validate command against allowlist and blocklist.
    Returns (is_safe, reason).
    """
    cmd_lower = command.lower().strip()

    # Check blocked patterns first
    for blocked in BLOCKED_PATTERNS:
        if blocked in cmd_lower:
            return False, f"Blocked pattern detected: {blocked}"

    # Extract the first cmdlet from the command
    # Handle multiline and piped commands
    cmdlets_found = []
    for segment in cmd_lower.replace(";", "\n").replace("|", "\n").split("\n"):
        segment = segment.strip()
        if not segment or segment.startswith("#") or segment.startswith("$"):
            continue
        # Extract first word (the cmdlet)
        first_word = segment.split()[0] if segment.split() else ""
        # Skip variable assignments
        if "=" in first_word:
            continue
        # Skip flow control
        if first_word in ("if", "else", "elseif", "foreach", "for", "while",
                          "do", "try", "catch", "finally", "switch", "}", "{"):
            continue
        if first_word:
            cmdlets_found.append(first_word)

    if not cmdlets_found:
        # Pure variable assignment or flow control - allow
        return True, "No cmdlets detected (variable/flow only)"

    for cmdlet in cmdlets_found:
        is_allowed = any(cmdlet.startswith(prefix) for prefix in ALLOWED_CMDLET_PREFIXES)
        if not is_allowed:
            return False, f"Cmdlet not in allowlist: {cmdlet}"

    return True, "All cmdlets allowed"


def verify_internal_request(request: Request) -> bool:
    """Verify the request comes from N8N or internal service."""
    # Check for internal header
    auth_header = request.headers.get("X-Internal-Secret", "")
    if auth_header and hmac.compare_digest(auth_header, INTERNAL_SECRET):
        return True

    # Check for basic auth from N8N
    auth = request.headers.get("Authorization", "")
    if auth:
        return True

    # Allow from localhost/docker network
    client_host = request.client.host if request.client else ""
    if client_host in ("127.0.0.1", "::1", "172.18.0.1") or client_host.startswith("172."):
        return True

    return False


# ============================================================
# Variable injection
# ============================================================

def build_powershell_script(command: str, context: Optional[Dict] = None) -> str:
    """
    Wrap command with variable declarations from context.
    This allows N8N to pass $UPN, $ManagerEmail, etc.
    """
    lines = ["$ErrorActionPreference = 'Stop'", ""]

    if context:
        for key, value in context.items():
            # Sanitize key name
            safe_key = "".join(c for c in key if c.isalnum() or c == "_")
            # Escape value
            safe_value = str(value).replace("'", "''")
            lines.append(f"${safe_key} = '{safe_value}'")
        lines.append("")

    lines.append("# === Runbook Command ===")
    lines.append(command)

    return "\n".join(lines)


# ============================================================
# Execution endpoint
# ============================================================

@router.post("/execute-server-powershell")
async def execute_server_powershell(
    req: ServerPowerShellRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    """
    Execute PowerShell command on the backend server.
    Used by N8N workflows for M365 management commands.
    """
    # Security: verify internal origin
    if not verify_internal_request(request):
        logger.warning(f"Unauthorized server PowerShell request from {request.client.host}")
        raise HTTPException(403, "Internal endpoint - not authorized")

    # Safety: validate command
    is_safe, reason = verify_command_safety(req.command)
    if not is_safe:
        logger.warning(f"Blocked unsafe command: {reason} | cmd: {req.command[:100]}")
        raise HTTPException(400, f"Command blocked by safety validator: {reason}")

    # Enforce timeout limits
    timeout = min(req.timeout, MAX_TIMEOUT)

    # Build full script with context variables
    script = build_powershell_script(req.command, req.context)

    # Hash for audit
    cmd_hash = hashlib.sha256(req.command.encode()).hexdigest()[:16]

    logger.info(
        f"⚡ Server PowerShell execution | "
        f"runbook={req.runbook_id} step={req.step_index} "
        f"hash={cmd_hash} timeout={timeout}s"
    )

    start_time = datetime.now(timezone.utc)

    try:
        # Execute via pwsh subprocess
        result = await asyncio.wait_for(
            asyncio.get_event_loop().run_in_executor(
                None,
                lambda: subprocess.run(
                    ["pwsh", "-NoProfile", "-NonInteractive", "-Command", script],
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                )
            ),
            timeout=timeout + 5
        )

        duration_ms = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)

        success = result.returncode == 0
        output = result.stdout.strip() if result.stdout else ""
        error = result.stderr.strip() if result.stderr else None

        # Truncate long output
        if len(output) > 10000:
            output = output[:10000] + "\n... [truncated]"
        if error and len(error) > 5000:
            error = error[:5000] + "\n... [truncated]"

        logger.info(
            f"{'✅' if success else '❌'} Server PowerShell complete | "
            f"hash={cmd_hash} exit={result.returncode} duration={duration_ms}ms"
        )

        # Audit log
        try:
            db.execute(
                __import__('sqlalchemy').text(
                    "INSERT INTO audit_log (action, entity_type, entity_id, details, created_at) "
                    "VALUES (:action, :etype, :eid, :details, NOW())"
                ),
                {
                    "action": "server_powershell_execute",
                    "etype": "runbook",
                    "eid": req.runbook_id or 0,
                    "details": json.dumps({
                        "command_hash": cmd_hash,
                        "step_index": req.step_index,
                        "workflow_id": req.workflow_id,
                        "success": success,
                        "exit_code": result.returncode,
                        "duration_ms": duration_ms,
                    })
                }
            )
            db.commit()
        except Exception as audit_err:
            logger.debug(f"Audit log skipped: {audit_err}")

        return ServerPowerShellResponse(
            success=success,
            output=output,
            error=error,
            exit_code=result.returncode,
            duration_ms=duration_ms,
            command_hash=cmd_hash,
            executed_at=start_time.isoformat(),
        )

    except asyncio.TimeoutError:
        duration_ms = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)
        logger.error(f"⏰ Server PowerShell timeout | hash={cmd_hash} timeout={timeout}s")
        return ServerPowerShellResponse(
            success=False,
            output="",
            error=f"Command timed out after {timeout} seconds",
            exit_code=-1,
            duration_ms=duration_ms,
            command_hash=cmd_hash,
            executed_at=start_time.isoformat(),
        )
    except Exception as e:
        duration_ms = int((datetime.now(timezone.utc) - start_time).total_seconds() * 1000)
        logger.error(f"❌ Server PowerShell error | hash={cmd_hash} error={e}")
        return ServerPowerShellResponse(
            success=False,
            output="",
            error=str(e),
            exit_code=-1,
            duration_ms=duration_ms,
            command_hash=cmd_hash,
            executed_at=start_time.isoformat(),
        )


# ============================================================
# Health check for N8N
# ============================================================

@router.get("/powershell-status")
async def powershell_status(request: Request):
    """Check if server-side PowerShell is available and modules are loaded."""
    if not verify_internal_request(request):
        raise HTTPException(403, "Internal endpoint")

    try:
        result = subprocess.run(
            ["pwsh", "-NoProfile", "-Command",
             "Get-Module -ListAvailable ExchangeOnlineManagement, Microsoft.Graph "
             "| Select-Object Name, Version | ConvertTo-Json"],
            capture_output=True, text=True, timeout=15
        )
        modules = json.loads(result.stdout) if result.stdout.strip() else []
        if isinstance(modules, dict):
            modules = [modules]

        return {
            "available": True,
            "pwsh_available": True,
            "modules": [{"name": m.get("Name"), "version": str(m.get("Version"))} for m in modules],
            "checked_at": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        return {"available": False, "error": str(e)}
