"""
OPSIS N8N Workflow Generator
Automatically generates N8N workflows from approved Knowledge Base runbooks.

Flow:
1. Claude (Tier 3) classifies each runbook step by execution type
2. Assembles valid N8N workflow JSON from step classifications
3. Deploys to N8N via REST API as inactive draft
4. Links workflow ID back to the CustomRunbook record

Execution types:
- agent_push: PowerShell/cmd executed on endpoint via WebSocket agent
- graph_api: Microsoft 365 action via Graph API (user mgmt, license, security)
- create_ticket: Creates OPSIS ticket for manual/human steps
- notification: Sends email/alert notification
- wait: Pause/delay between steps
- conditional: Branch based on previous step result
"""

import os
import json
import logging
import hashlib
from typing import Dict, List, Optional
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

# OPSIS backend base URL (inside Docker network)
BACKEND_URL = "http://opsis-backend:8000"

# N8N node type versions (v2.4.8 compatible)
HTTP_REQUEST_VERSION = 4.2
WEBHOOK_VERSION = 2
SET_VERSION = 3.4
IF_VERSION = 2
WAIT_VERSION = 1.1
CODE_VERSION = 2


class WorkflowGenerator:
    """Generates N8N workflows from classified runbook steps."""

    def __init__(self):
        self._claude = None

    @property
    def claude(self):
        if self._claude is None:
            from services.claude_service import claude_service
            self._claude = claude_service
        return self._claude

    # ── Step 1: Claude classifies each runbook step ──────────────

    def classify_runbook_steps(self, runbook_data: Dict) -> List[Dict]:
        """
        Use Claude to classify each remediation step by execution type.
        Returns a list of classified steps with execution metadata.
        """
        if not self.claude.is_available():
            raise RuntimeError("Claude API not available for step classification")

        prompt = self._build_classification_prompt(runbook_data)

        try:
            response = self.claude.client.messages.create(
                model=self.claude.model,
                max_tokens=4000,
                temperature=0.1,
                messages=[{"role": "user", "content": prompt}]
            )
            text = response.content[0].text if response.content else ""
            result = self._parse_json_response(text)

            if not result or "steps" not in result:
                logger.error("Classification returned no steps")
                return []

            classified = result["steps"]
            logger.info(
                f"Classified {len(classified)} steps: "
                + ", ".join(f"{s.get('execution_type', '?')}" for s in classified)
            )
            return classified

        except Exception as e:
            logger.error(f"Step classification failed: {e}")
            return []

    # ── Step 2: Assemble N8N workflow JSON ───────────────────────

    def build_workflow(
        self,
        runbook_id: int,
        runbook_title: str,
        classified_steps: List[Dict],
        category: str = "custom",
        risk_level: str = "medium",
    ) -> Optional[Dict]:
        """
        Assemble a complete N8N workflow JSON from classified steps.
        Uses standard N8N nodes (HTTP Request, Code, Wait, IF) to call
        OPSIS backend API endpoints.
        """
        if not classified_steps:
            logger.warning("No classified steps to build workflow from")
            return None

        safe_title = runbook_title[:80].replace('"', "'")
        workflow_name = f"[KB-{runbook_id}] {safe_title}"

        nodes = []
        connections = {}
        x_pos = 250
        y_pos = 300
        x_step = 250
        prev_node_name = None

        # ── Trigger node: Manual + Webhook ──
        trigger_name = "Webhook Trigger"
        nodes.append({
            "parameters": {
                "path": f"runbook/{runbook_id}",
                "responseMode": "lastNode",
                "options": {}
            },
            "id": self._node_id(0),
            "name": trigger_name,
            "type": "n8n-nodes-base.webhook",
            "typeVersion": WEBHOOK_VERSION,
            "position": [x_pos, y_pos],
        })
        prev_node_name = trigger_name
        x_pos += x_step + 50

        # ── Init node: Set context variables ──
        init_name = "Init Context"
        nodes.append({
            "parameters": {
                "mode": "raw",
                "jsonOutput": json.dumps({
                    "runbook_id": runbook_id,
                    "runbook_title": runbook_title,
                    "started_at": "={{ $now.toISO() }}",
                    "step_results": [],
                    "status": "running",
                    "device_id": "={{ $json.body?.device_id || $json.device_id || '' }}",
                    "client_id": "={{ $json.body?.client_id || $json.client_id || '' }}",
                    "tenant_id": "={{ $json.body?.tenant_id || $json.tenant_id || '' }}",
                }),
                "options": {}
            },
            "id": self._node_id(1),
            "name": init_name,
            "type": "n8n-nodes-base.set",
            "typeVersion": SET_VERSION,
            "position": [x_pos, y_pos],
        })
        self._connect(connections, prev_node_name, init_name)
        prev_node_name = init_name
        x_pos += x_step

        # ── Build a node for each classified step ──
        for idx, step in enumerate(classified_steps):
            exec_type = step.get("execution_type", "agent_push")
            description = step.get("description", f"Step {idx + 1}")
            step_name = f"Step {idx + 1}: {description[:40]}"

            node = self._build_step_node(
                step=step,
                idx=idx + 2,  # offset for trigger + init
                name=step_name,
                x=x_pos,
                y=y_pos,
                exec_type=exec_type,
                runbook_id=runbook_id,
            )

            if node:
                nodes.append(node)
                self._connect(connections, prev_node_name, step_name)
                prev_node_name = step_name
                x_pos += x_step

                # If step has error handling, add an IF node
                if step.get("continue_on_error") is False:
                    error_check_name = f"Check {idx + 1}"
                    error_node = {
                        "parameters": {
                            "conditions": {
                                "options": {"caseSensitive": True, "leftValue": "", "typeValidation": "strict"},
                                "conditions": [{
                                    "id": self._short_id(idx),
                                    "leftValue": "={{ $json.success }}",
                                    "rightValue": True,
                                    "operator": {"type": "boolean", "operation": "equals"}
                                }]
                            }
                        },
                        "id": self._node_id(idx + 100),
                        "name": error_check_name,
                        "type": "n8n-nodes-base.if",
                        "typeVersion": IF_VERSION,
                        "position": [x_pos, y_pos],
                    }
                    nodes.append(error_node)
                    self._connect(connections, prev_node_name, error_check_name)
                    prev_node_name = error_check_name
                    x_pos += x_step

        # ── Final node: Record result ──
        result_name = "Record Result"
        nodes.append({
            "parameters": {
                "method": "POST",
                "url": f"{BACKEND_URL}/api/knowledge-base/runbooks/{runbook_id}/record-execution",
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "success", "value": "={{ $json.status !== 'failed' }}"},
                        {"name": "step_results", "value": "={{ JSON.stringify($json.step_results || []) }}"},
                        {"name": "completed_at", "value": "={{ $now.toISO() }}"},
                    ]
                },
                "options": {"timeout": 30000}
            },
            "id": self._node_id(999),
            "name": result_name,
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": HTTP_REQUEST_VERSION,
            "position": [x_pos, y_pos],
        })
        self._connect(connections, prev_node_name, result_name)

        # ── Respond node ──
        x_pos += x_step
        respond_name = "Respond"
        nodes.append({
            "parameters": {
                "respondWith": "json",
                "responseBody": '={{ JSON.stringify({ "status": "completed", "runbook_id": ' + str(runbook_id) + ', "steps_executed": ' + str(len(classified_steps)) + ' }) }}'
            },
            "id": self._node_id(1000),
            "name": respond_name,
            "type": "n8n-nodes-base.respondToWebhook",
            "typeVersion": 1,
            "position": [x_pos, y_pos],
        })
        self._connect(connections, result_name, respond_name)

        return {
            "name": workflow_name,
            "nodes": nodes,
            "connections": connections,
            "active": False,  # Deploy as INACTIVE draft — human activates
            "settings": {
                "executionOrder": "v1",
                "saveExecutionProgress": True,
                "saveManualExecutions": True,
                "saveDataErrorExecution": "all",
                "saveDataSuccessExecution": "all",
                "executionTimeout": 600,
            },
            "tags": [
                {"name": "knowledge-base"},
                {"name": "auto-generated"},
                {"name": f"risk-{risk_level}"},
                {"name": category},
            ],
        }

    # ── Deploy to N8N ────────────────────────────────────────────

    async def deploy_workflow(self, workflow_json: Dict) -> Optional[str]:
        """Push workflow JSON to N8N via REST API. Returns workflow_id."""
        from services.n8n_client import n8n_client

        if not n8n_client.is_available():
            logger.warning("N8N not available — skipping workflow deployment")
            return None

        workflow_id = await n8n_client.create_workflow(workflow_json)
        if workflow_id:
            logger.info(f"✅ Deployed N8N workflow: {workflow_id} — {workflow_json.get('name')}")
        else:
            logger.error(f"❌ Failed to deploy workflow: {workflow_json.get('name')}")

        return workflow_id

    # ── Full pipeline: classify → build → deploy ─────────────────

    async def generate_and_deploy(
        self,
        runbook_id: int,
        runbook_title: str,
        runbook_data: Dict,
        category: str = "custom",
        risk_level: str = "medium",
    ) -> Dict:
        """
        Complete pipeline:
        1. Claude classifies steps
        2. Build N8N workflow JSON
        3. Deploy to N8N as inactive draft
        Returns result dict with workflow_id and classification.
        """
        result = {
            "runbook_id": runbook_id,
            "classified_steps": [],
            "workflow_json": None,
            "n8n_workflow_id": None,
            "status": "pending",
            "error": None,
        }

        # Step 1: Classify
        try:
            classified = self.classify_runbook_steps(runbook_data)
            result["classified_steps"] = classified
            if not classified:
                result["status"] = "classification_failed"
                result["error"] = "No steps could be classified"
                return result
        except Exception as e:
            result["status"] = "classification_failed"
            result["error"] = str(e)
            return result

        # Step 2: Build
        try:
            workflow_json = self.build_workflow(
                runbook_id=runbook_id,
                runbook_title=runbook_title,
                classified_steps=classified,
                category=category,
                risk_level=risk_level,
            )
            result["workflow_json"] = workflow_json
            if not workflow_json:
                result["status"] = "build_failed"
                result["error"] = "Failed to build workflow JSON"
                return result
        except Exception as e:
            result["status"] = "build_failed"
            result["error"] = str(e)
            return result

        # Step 3: Deploy
        try:
            workflow_id = await self.deploy_workflow(workflow_json)
            result["n8n_workflow_id"] = workflow_id
            result["status"] = "deployed" if workflow_id else "deploy_failed"
            if not workflow_id:
                result["error"] = "N8N deployment returned no workflow ID"
        except Exception as e:
            result["status"] = "deploy_failed"
            result["error"] = str(e)

        return result

    # ── Node builders ────────────────────────────────────────────

    def _build_step_node(
        self, step: Dict, idx: int, name: str, x: int, y: int,
        exec_type: str, runbook_id: int
    ) -> Optional[Dict]:
        """Build appropriate N8N node based on execution type."""

        if exec_type == "server_powershell":
            return self._build_server_powershell_node(step, idx, name, x, y, runbook_id)
        elif exec_type == "agent_push":
            return self._build_agent_push_node(step, idx, name, x, y, runbook_id)
        elif exec_type == "graph_api":
            return self._build_graph_api_node(step, idx, name, x, y)
        elif exec_type == "create_ticket":
            return self._build_ticket_node(step, idx, name, x, y, runbook_id)
        elif exec_type == "notification":
            return self._build_notification_node(step, idx, name, x, y)
        elif exec_type == "wait":
            return self._build_wait_node(step, idx, name, x, y)
        else:
            # Default: treat as server powershell for M365, agent push for endpoint
            return self._build_server_powershell_node(step, idx, name, x, y, runbook_id)

    def _build_server_powershell_node(
        self, step: Dict, idx: int, name: str, x: int, y: int, runbook_id: int
    ) -> Dict:
        """HTTP Request node that calls OPSIS backend to run M365 PowerShell on the server."""
        command = step.get("command", step.get("action", ""))
        timeout = step.get("timeout", 30000)

        body_params = [
            {"name": "command", "value": command},
            {"name": "timeout", "value": str(min(int(timeout / 1000), 120))},
            {"name": "runbook_id", "value": str(runbook_id)},
            {"name": "step_index", "value": str(idx)},
        ]

        # Add context variables if present
        context = step.get("context", {})
        if context:
            body_params.append(
                {"name": "context", "value": json.dumps(context)}
            )

        return {
            "parameters": {
                "method": "POST",
                "url": f"{BACKEND_URL}/api/internal/execute-server-powershell",
                "sendHeaders": True,
                "headerParameters": {
                    "parameters": [
                        {"name": "X-Internal-Secret", "value": "={{ $env.INTERNAL_API_SECRET || '' }}"},
                    ]
                },
                "sendBody": True,
                "bodyParameters": {
                    "parameters": body_params
                },
                "options": {"timeout": timeout + 10000}
            },
            "id": self._node_id(idx),
            "name": name,
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": HTTP_REQUEST_VERSION,
            "position": [x, y],
        }

    def _build_agent_push_node(
        self, step: Dict, idx: int, name: str, x: int, y: int, runbook_id: int
    ) -> Dict:
        """HTTP Request node that calls OPSIS backend to push command to agent."""
        command = step.get("command", step.get("action", ""))
        timeout = step.get("timeout", 30000)

        return {
            "parameters": {
                "method": "POST",
                "url": f"{BACKEND_URL}/api/fleet-command/execute-step",
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "device_id", "value": "={{ $('Init Context').item.json.device_id }}"},
                        {"name": "client_id", "value": "={{ $('Init Context').item.json.client_id }}"},
                        {"name": "command", "value": command},
                        {"name": "command_type", "value": step.get("type", "powershell")},
                        {"name": "timeout", "value": str(timeout)},
                        {"name": "runbook_id", "value": str(runbook_id)},
                        {"name": "step_index", "value": str(idx)},
                    ]
                },
                "options": {"timeout": timeout + 10000}
            },
            "id": self._node_id(idx),
            "name": name,
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": HTTP_REQUEST_VERSION,
            "position": [x, y],
        }

    def _build_graph_api_node(
        self, step: Dict, idx: int, name: str, x: int, y: int
    ) -> Dict:
        """HTTP Request node that calls OPSIS Graph Executor."""
        endpoint = step.get("graph_endpoint", "")
        method = step.get("graph_method", "POST")
        body = step.get("graph_body", {})

        return {
            "parameters": {
                "method": "POST",
                "url": f"{BACKEND_URL}/api/m365/graph/execute",
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "tenant_id", "value": "={{ $('Init Context').item.json.tenant_id }}"},
                        {"name": "endpoint", "value": endpoint},
                        {"name": "method", "value": method},
                        {"name": "body", "value": json.dumps(body)},
                    ]
                },
                "options": {"timeout": 30000}
            },
            "id": self._node_id(idx),
            "name": name,
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": HTTP_REQUEST_VERSION,
            "position": [x, y],
        }

    def _build_ticket_node(
        self, step: Dict, idx: int, name: str, x: int, y: int, runbook_id: int
    ) -> Dict:
        """HTTP Request node that creates an OPSIS ticket for manual steps."""
        return {
            "parameters": {
                "method": "POST",
                "url": f"{BACKEND_URL}/api/tickets",
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "title", "value": step.get("description", "Manual step required")},
                        {"name": "description", "value": step.get("manual_instructions", step.get("description", ""))},
                        {"name": "priority", "value": step.get("priority", "medium")},
                        {"name": "category", "value": "workflow"},
                        {"name": "source", "value": f"n8n-runbook-{runbook_id}"},
                        {"name": "client_id", "value": "={{ $('Init Context').item.json.client_id }}"},
                    ]
                },
                "options": {"timeout": 15000}
            },
            "id": self._node_id(idx),
            "name": name,
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": HTTP_REQUEST_VERSION,
            "position": [x, y],
        }

    def _build_notification_node(
        self, step: Dict, idx: int, name: str, x: int, y: int
    ) -> Dict:
        """HTTP Request node that sends notification via OPSIS email service."""
        return {
            "parameters": {
                "method": "POST",
                "url": f"{BACKEND_URL}/api/notifications/send",
                "sendBody": True,
                "bodyParameters": {
                    "parameters": [
                        {"name": "subject", "value": step.get("subject", "Workflow Notification")},
                        {"name": "message", "value": step.get("message", step.get("description", ""))},
                        {"name": "severity", "value": step.get("severity", "info")},
                    ]
                },
                "options": {"timeout": 15000}
            },
            "id": self._node_id(idx),
            "name": name,
            "type": "n8n-nodes-base.httpRequest",
            "typeVersion": HTTP_REQUEST_VERSION,
            "position": [x, y],
        }

    def _build_wait_node(
        self, step: Dict, idx: int, name: str, x: int, y: int
    ) -> Dict:
        """Wait/delay node."""
        seconds = step.get("wait_seconds", 30)
        return {
            "parameters": {
                "amount": seconds,
                "unit": "seconds",
            },
            "id": self._node_id(idx),
            "name": name,
            "type": "n8n-nodes-base.wait",
            "typeVersion": WAIT_VERSION,
            "position": [x, y],
        }

    # ── Prompt builder ───────────────────────────────────────────

    def _build_classification_prompt(self, runbook_data: Dict) -> str:
        return f"""You are an expert IT workflow automation architect for MSP environments.

Analyze this approved runbook and classify EACH step by its execution type.
Your job is to determine HOW each step should be automated.

=== RUNBOOK ===
Title: {runbook_data.get('title', '')}
Problem: {runbook_data.get('problem_description', '')}
Category: {runbook_data.get('category', '')}

Diagnostic Steps:
{json.dumps(runbook_data.get('diagnostic_steps', []), indent=2)}

Remediation Steps:
{json.dumps(runbook_data.get('remediation_steps', []), indent=2)}

Verification Steps:
{json.dumps(runbook_data.get('verification_steps_desc', runbook_data.get('verification_steps', [])), indent=2)}

Generated PowerShell (if available):
{json.dumps(runbook_data.get('generated_powershell', []), indent=2)}

=== EXECUTION TYPES ===
- "server_powershell": M365/Exchange/AzureAD PowerShell commands that run on the OPSIS SERVER (not on an endpoint). Use for ANY step involving Exchange Online, Microsoft Graph, Azure AD, MSOnline, SharePoint Online, Teams management. These commands use modules like ExchangeOnlineManagement, Microsoft.Graph, MSOnline, MicrosoftTeams. The server has these modules installed and runs them directly.
- "agent_push": Command runs on a Windows ENDPOINT via OPSIS agent (local PowerShell, cmd, service restart, registry edit, file operations, credential manager, user profile cleanup). Use ONLY for steps that touch the local machine/workstation.
- "graph_api": Direct Microsoft Graph REST API call (alternative to PowerShell for simple user/group operations). Use when a direct REST call is cleaner than PowerShell.
- "create_ticket": Step requires human intervention that cannot be automated (physical hardware, vendor contact, approval needed, policy decision). Creates an OPSIS ticket.
- "notification": Send email/alert to MSP admin or end user (status update, completion notice, warning).
- "wait": Pause between steps (service restart settling, replication delay, user action needed).

=== CLASSIFICATION RULES ===
1. If a step uses Exchange Online cmdlets (Set-Mailbox, Get-Mailbox, Set-MailboxAutoReplyConfiguration, Get-DistributionGroup, etc.) → "server_powershell"
2. If a step uses MSOnline cmdlets (Get-MsolUser, Set-MsolUser, Set-MsolUserPassword, etc.) → "server_powershell"
3. If a step uses AzureAD cmdlets (Get-AzureADUser, Remove-AzureADGroupMember, etc.) → "server_powershell"
4. If a step uses Microsoft Graph PowerShell (Get-MgUser, Update-MgUser, etc.) → "server_powershell"
5. If a step uses Teams cmdlets (Get-Team, Remove-TeamUser, etc.) → "server_powershell"
6. If a step uses SPO cmdlets (Get-SPOSite, Set-SPOUser, etc.) → "server_powershell"
7. If a step uses Connect-ExchangeOnline, Connect-MgGraph, Connect-MsolService → "server_powershell"
8. If a step touches local Windows machine (cmdkey, user profiles, C:\\ paths, local services, registry) → "agent_push"
9. If a step says "contact", "physically", "manually", "call vendor", "requires approval", "collect" → "create_ticket"
10. If a step says "notify", "email", "alert", "inform", "send completion" → "notification"
11. If a step says "wait", "allow time", "let propagate" → "wait"
12. Include ALL steps: diagnostics first, then remediation, then verification
13. For server_powershell steps, include the FULL PowerShell command

=== OUTPUT JSON ===
{{
  "steps": [
    {{
      "order": 1,
      "description": "What this step does",
      "execution_type": "agent_push|graph_api|create_ticket|notification|wait",
      "command": "PowerShell command or empty",
      "type": "powershell|cmd|service|registry|file|diagnostic",
      "timeout": 30000,
      "continue_on_error": true,
      "graph_endpoint": "/users/{{userId}}/...",
      "graph_method": "GET|POST|PATCH|DELETE",
      "graph_body": {{}},
      "manual_instructions": "For create_ticket type",
      "wait_seconds": 30,
      "subject": "For notification type",
      "message": "Notification message",
      "severity": "info|warning|critical"
    }}
  ],
  "workflow_summary": "Brief description of what this workflow automates",
  "estimated_duration_minutes": 5,
  "requires_agent": true,
  "requires_m365": false
}}

Return ONLY valid JSON. Include all diagnostic, remediation, AND verification steps."""

    # ── Utilities ────────────────────────────────────────────────

    def _connect(self, connections: Dict, from_name: str, to_name: str, output_index: int = 0):
        """Add a connection between two nodes."""
        if from_name not in connections:
            connections[from_name] = {"main": [[]]}
        while len(connections[from_name]["main"]) <= output_index:
            connections[from_name]["main"].append([])
        connections[from_name]["main"][output_index].append({
            "node": to_name,
            "type": "main",
            "index": 0
        })

    def _node_id(self, idx: int) -> str:
        """Generate a unique node ID."""
        return hashlib.md5(f"opsis-wf-node-{idx}".encode()).hexdigest()[:36]

    def _short_id(self, idx: int) -> str:
        """Generate a short ID for conditions."""
        return hashlib.md5(f"opsis-cond-{idx}".encode()).hexdigest()[:8]

    def _parse_json_response(self, text: str) -> Optional[Dict]:
        """Parse JSON from Claude response, handling markdown fences."""
        import re
        try:
            cleaned = text.strip()
            if cleaned.startswith('```'):
                cleaned = re.sub(r'^```\w*\n?', '', cleaned)
                cleaned = re.sub(r'\n?```$', '', cleaned)
            start = cleaned.find('{')
            end = cleaned.rfind('}') + 1
            if start >= 0 and end > start:
                return json.loads(cleaned[start:end])
        except json.JSONDecodeError as e:
            logger.error(f"Workflow JSON parse error: {e}")
        return None


# Global instance
workflow_generator = WorkflowGenerator()
