#!/bin/bash
echo "=== OPSIS Frontend Deploy: Configure Modal with Policy + Maintenance + Groups ==="
echo ""

# Step 1: Copy components
echo "[1/4] Copying EndpointGroups.tsx..."
cp /root/opsis-deploy/components/EndpointGroups.tsx /opt/opsis/frontend/src/components/EndpointGroups.tsx

echo "[2/4] Copying RemediationPolicy.tsx..."
cp /root/opsis-deploy/components/RemediationPolicy.tsx /opt/opsis/frontend/src/components/RemediationPolicy.tsx

echo "[3/4] Copying MaintenanceSchedules.tsx..."
cp /root/opsis-deploy/components/MaintenanceSchedules.tsx /opt/opsis/frontend/src/components/MaintenanceSchedules.tsx

echo "[4/4] Copying ClientManagementPage.tsx..."
cp /root/opsis-deploy/pages/ClientManagementPage.tsx /opt/opsis/frontend/src/pages/ClientManagementPage.tsx

echo ""
echo "=== Files copied. Now building... ==="
echo ""

cd /opt/opsis/frontend
docker build -t opsis-frontend --no-cache .
docker stop opsis-frontend && docker rm opsis-frontend
docker compose up -d frontend

echo ""
echo "=== Done! Wait ~3 seconds then check Client Management page ==="
echo "=== Each client row now has a gear icon (Configure) button ==="
