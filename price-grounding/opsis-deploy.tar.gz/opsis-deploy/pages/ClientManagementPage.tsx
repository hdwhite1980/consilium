import { useState, useEffect } from 'react';
import { Building2, Plus, Edit, Trash2, BarChart3, CheckCircle, XCircle, AlertCircle, Server, Ticket, Key, X, RefreshCw, Settings, Folder, Calendar, Shield } from 'lucide-react';
import api from '../services/api';
import AgentSetup from '../components/AgentSetup';
import RemediationPolicy from '../components/RemediationPolicy';
import MaintenanceSchedules from '../components/MaintenanceSchedules';
import EndpointGroups from '../components/EndpointGroups';

interface Client { id: number; name: string; company_name: string; email: string; phone: string; subscription_tier: string; is_active: boolean; industry: string; created_at: string; endpoint_count: number; }
interface ClientStats { endpoints: { total: number; online: number; offline: number; limit: number }; tickets: { open: number; resolved_30d: number }; m365: { connected: boolean; tenant_id: string | null; status: string | null }; }

const CONFIG_TABS = [
  { key: 'policy', label: 'Remediation Policy', icon: Shield },
  { key: 'maintenance', label: 'Maintenance', icon: Calendar },
  { key: 'groups', label: 'Endpoint Groups', icon: Folder },
] as const;

type ConfigTab = typeof CONFIG_TABS[number]['key'];

export default function ClientManagementPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [addForm, setAddForm] = useState({ name: '', company_name: '', email: '', phone: '', subscription_tier: 'starter', industry: '', billing_email: '', sla_response_time_hours: 24, sla_resolution_time_hours: 72 });
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [editForm, setEditForm] = useState<any>({});
  const [showStatsDialog, setShowStatsDialog] = useState(false);
  const [statsClient, setStatsClient] = useState<Client | null>(null);
  const [stats, setStats] = useState<ClientStats | null>(null);
  const [statsLoading, setStatsLoading] = useState(false);
  const [showAgentSetup, setShowAgentSetup] = useState(false);
  const [showBillingReminder, setShowBillingReminder] = useState(false);
  const [agentSetupClient, setAgentSetupClient] = useState<Client | null>(null);

  // Configure modal state
  const [configClient, setConfigClient] = useState<Client | null>(null);
  const [configTab, setConfigTab] = useState<ConfigTab>('policy');

  useEffect(() => { setShowAddDialog(false); setShowEditDialog(false); setShowStatsDialog(false); setShowAgentSetup(false); }, []);
  useEffect(() => { loadClients(); }, []);

  const loadClients = async () => { try { setLoading(true); const r = await api.get('/clients'); setClients(r.data); } catch (e: any) { setError(e.response?.data?.detail || 'Failed to load'); } finally { setLoading(false); } };
  const flash = (m: string) => { setSuccess(m); setTimeout(() => setSuccess(''), 3000); };

  const handleAddClient = async () => { try { setError(''); await api.post('/clients', addForm); flash('Client added'); setShowAddDialog(false); try { const b = await api.get('/billing/status'); if (!b.data.has_subscription && !b.data.has_payment_method) setShowBillingReminder(true); } catch {} setAddForm({ name: '', company_name: '', email: '', phone: '', subscription_tier: 'starter', industry: '', billing_email: '', sla_response_time_hours: 24, sla_resolution_time_hours: 72 }); loadClients(); } catch (e: any) { setError(e.response?.data?.detail || 'Failed'); } };
  const openEditDialog = (c: Client) => { setEditingClient(c); setEditForm({ name: c.name, company_name: c.company_name, email: c.email, phone: c.phone, subscription_tier: c.subscription_tier, industry: c.industry, is_active: c.is_active }); setShowEditDialog(true); };
  const handleEditClient = async () => { if (!editingClient) return; try { setError(''); await api.patch('/clients/' + editingClient.id, editForm); flash('Client updated'); setShowEditDialog(false); setEditingClient(null); loadClients(); } catch (e: any) { setError(e.response?.data?.detail || 'Failed'); } };
  const handleDeleteClient = async (c: Client) => { if (!confirm('Delete ' + c.name + '?')) return; try { setError(''); await api.delete('/clients/' + c.id); flash('Client deleted'); loadClients(); } catch (e: any) { setError(e.response?.data?.detail || 'Failed'); } };
  const openStatsDialog = async (c: Client) => { setStatsClient(c); setShowStatsDialog(true); setStatsLoading(true); try { const r = await api.get('/clients/' + c.id + '/stats'); setStats(r.data); } catch (e: any) { setError(e.response?.data?.detail || 'Failed'); } finally { setStatsLoading(false); } };
  const openAgentSetup = (c: Client) => { setAgentSetupClient(c); setShowAgentSetup(true); };
  const openConfigModal = (c: Client) => { setConfigClient(c); setConfigTab('policy'); };

  const tierColor = (t: string) => t === 'enterprise' ? 'bg-purple-100 text-purple-700' : t === 'business' ? 'bg-primary-50 text-primary-700' : t === 'professional' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-600';

  const active = clients.filter(c => c.is_active).length;
  const totalEndpoints = clients.reduce((s, c) => s + (c.endpoint_count || 0), 0);

  if (loading) return <div className="flex items-center justify-center h-64"><RefreshCw className="w-5 h-5 animate-spin text-primary-400" /></div>;

  const Modal = ({ open, onClose, title, wide, children, footer }: { open: boolean; onClose: () => void; title: string; wide?: boolean; children: React.ReactNode; footer: React.ReactNode }) => {
    if (!open) return null;
    return (
      <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={onClose}>
        <div className={"bg-white rounded-2xl shadow-2xl w-full " + (wide ? "max-w-2xl" : "max-w-md")} onClick={e => e.stopPropagation()}>
          <div className="p-5 border-b border-gray-100 flex items-center justify-between"><h2 className="text-base font-bold text-gray-900">{title}</h2><button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-4 h-4" /></button></div>
          <div className="p-5">{children}</div>
          <div className="p-5 border-t border-gray-100 flex gap-3">{footer}</div>
        </div>
      </div>
    );
  };

  const Field = ({ label, span, children }: { label: string; span?: boolean; children: React.ReactNode }) => <div className={span ? "col-span-2" : ""}><label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">{label}</label>{children}</div>;
  const inputCls = "w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary-400/50";

  return (
    <div className="p-6 lg:p-8 max-w-[1400px]">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Client Management</h1>
        <button onClick={() => setShowAddDialog(true)} className="flex items-center gap-2 px-4 py-2 text-sm font-medium bg-opsis-midnight text-white rounded-lg hover:bg-gray-800 transition-colors"><Plus className="w-4 h-4" />Add Client</button>
      </div>

      {error && <div className="mb-6 p-3 bg-red-50/50 border border-red-200 rounded-xl text-xs text-critical flex items-center gap-1.5"><AlertCircle className="w-3.5 h-3.5" />{error}<button onClick={() => setError('')} className="ml-auto"><X className="w-3 h-3" /></button></div>}
      {success && <div className="mb-6 p-3 bg-green-50/50 border border-green-200 rounded-xl text-xs text-healthy flex items-center gap-1.5"><CheckCircle className="w-3.5 h-3.5" />{success}</div>}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl border border-gray-200 p-5 card-hover"><div className="flex items-center justify-between mb-3"><p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Clients</p><Building2 className="w-4 h-4 text-[#2DD4FF]" /></div><p className="text-3xl font-bold text-gray-900 stat-value">{clients.length}</p></div>
        <div className="bg-white rounded-xl border border-gray-200 p-5 card-hover"><div className="flex items-center justify-between mb-3"><p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Active</p><CheckCircle className="w-4 h-4 text-healthy" /></div><p className="text-3xl font-bold text-gray-900 stat-value">{active}</p></div>
        <div className="bg-white rounded-xl border border-gray-200 p-5 card-hover"><div className="flex items-center justify-between mb-3"><p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Endpoints</p><Server className="w-4 h-4 text-[#1FB6A6]" /></div><p className="text-3xl font-bold text-gray-900 stat-value">{totalEndpoints}</p></div>
        <div className="bg-white rounded-xl border border-gray-200 p-5 card-hover"><div className="flex items-center justify-between mb-3"><p className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Inactive</p><XCircle className="w-4 h-4 text-warning" /></div><p className="text-3xl font-bold text-gray-900 stat-value">{clients.length - active}</p></div>
      </div>

      {/* Clients List */}
      <div className="bg-white rounded-xl border border-gray-200 divide-y divide-gray-100">
        {clients.map(client => (
          <div key={client.id} className="px-6 py-4 hover:bg-gray-50/30 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4 min-w-0">
                <div className="w-9 h-9 rounded-full bg-opsis-midnight flex items-center justify-center flex-shrink-0"><span className="text-xs font-bold text-white">{(client.name || '?').charAt(0).toUpperCase()}</span></div>
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-gray-900 truncate">{client.name}</p>
                    <span className={"w-1.5 h-1.5 rounded-full flex-shrink-0 " + (client.is_active ? 'bg-healthy' : 'bg-gray-300')} />
                    <span className={"text-[10px] font-semibold px-2 py-0.5 rounded-full " + tierColor(client.subscription_tier)}>{client.subscription_tier}</span>
                  </div>
                  <p className="text-[10px] text-gray-400 truncate">{client.company_name}{client.industry ? ' · ' + client.industry : ''}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="hidden md:flex items-center gap-4 text-[10px] text-gray-400">
                  <span className="flex items-center gap-1"><Server className="w-3 h-3" />{client.endpoint_count || 0}</span>
                  <span>{client.email}</span>
                </div>
                <div className="flex items-center gap-0.5">
                  <button onClick={() => openConfigModal(client)} className="p-2 text-gray-400 hover:text-[#2DD4FF] hover:bg-[#2DD4FF]/5 rounded-lg transition-colors" title="Configure"><Settings className="w-3.5 h-3.5" /></button>
                  <button onClick={() => openStatsDialog(client)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg" title="Stats"><BarChart3 className="w-3.5 h-3.5" /></button>
                  <button onClick={() => openAgentSetup(client)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg" title="Agent Setup"><Key className="w-3.5 h-3.5" /></button>
                  <button onClick={() => openEditDialog(client)} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg" title="Edit"><Edit className="w-3.5 h-3.5" /></button>
                  <button onClick={() => handleDeleteClient(client)} className="p-2 text-gray-400 hover:text-critical hover:bg-red-50 rounded-lg" title="Delete"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Configure Modal */}
      {configClient && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setConfigClient(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div className="p-5 border-b border-gray-100 flex items-center justify-between flex-shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-opsis-midnight flex items-center justify-center">
                  <span className="text-xs font-bold text-white">{(configClient.name || '?').charAt(0).toUpperCase()}</span>
                </div>
                <div>
                  <h2 className="text-base font-bold text-gray-900">{configClient.name}</h2>
                  <p className="text-[10px] text-gray-400">{configClient.company_name} · Configuration</p>
                </div>
              </div>
              <button onClick={() => setConfigClient(null)} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-4 h-4" /></button>
            </div>

            {/* Tabs */}
            <div className="px-5 pt-3 border-b border-gray-100 flex gap-1 flex-shrink-0">
              {CONFIG_TABS.map(tab => (
                <button key={tab.key} onClick={() => setConfigTab(tab.key)}
                  className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold rounded-t-lg transition-colors ${
                    configTab === tab.key
                      ? 'bg-gray-50 text-gray-900 border border-gray-100 border-b-white -mb-px'
                      : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50/50'
                  }`}>
                  <tab.icon className="w-3.5 h-3.5" />
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-5">
              {configTab === 'policy' && (
                <RemediationPolicy clientId={configClient.id} clientName={configClient.name} />
              )}
              {configTab === 'maintenance' && (
                <MaintenanceSchedules clientId={configClient.id} />
              )}
              {configTab === 'groups' && (
                <EndpointGroups clientId={configClient.id} />
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add Client Modal */}
      <Modal open={showAddDialog} onClose={() => setShowAddDialog(false)} title="Add Client" wide
        footer={<><button onClick={() => setShowAddDialog(false)} className="flex-1 py-2.5 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200 transition-colors">Cancel</button><button onClick={handleAddClient} className="flex-1 py-2.5 bg-opsis-midnight text-white text-sm font-medium rounded-lg hover:bg-gray-800 transition-colors">Create</button></>}>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Client Name" span><input value={addForm.name} onChange={e => setAddForm({...addForm, name: e.target.value})} placeholder="John Doe" className={inputCls} /></Field>
          <Field label="Company"><input value={addForm.company_name} onChange={e => setAddForm({...addForm, company_name: e.target.value})} placeholder="Acme Corp" className={inputCls} /></Field>
          <Field label="Industry"><input value={addForm.industry} onChange={e => setAddForm({...addForm, industry: e.target.value})} placeholder="Technology" className={inputCls} /></Field>
          <Field label="Email"><input type="email" value={addForm.email} onChange={e => setAddForm({...addForm, email: e.target.value})} placeholder="john@acme.com" className={inputCls} /></Field>
          <Field label="Phone"><input value={addForm.phone} onChange={e => setAddForm({...addForm, phone: e.target.value})} placeholder="+1 555-0100" className={inputCls} /></Field>
          <Field label="Tier" span><select value={addForm.subscription_tier} onChange={e => setAddForm({...addForm, subscription_tier: e.target.value})} className={inputCls}><option value="starter">Starter</option><option value="professional">Professional</option><option value="business">Business</option><option value="enterprise">Enterprise</option></select></Field>
        </div>
      </Modal>

      {/* Edit Client Modal */}
      <Modal open={showEditDialog} onClose={() => setShowEditDialog(false)} title="Edit Client" wide
        footer={<><button onClick={() => setShowEditDialog(false)} className="flex-1 py-2.5 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200 transition-colors">Cancel</button><button onClick={handleEditClient} className="flex-1 py-2.5 bg-opsis-midnight text-white text-sm font-medium rounded-lg hover:bg-gray-800 transition-colors">Save</button></>}>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Client Name" span><input value={editForm.name || ''} onChange={e => setEditForm({...editForm, name: e.target.value})} className={inputCls} /></Field>
          <Field label="Company"><input value={editForm.company_name || ''} onChange={e => setEditForm({...editForm, company_name: e.target.value})} className={inputCls} /></Field>
          <Field label="Industry"><input value={editForm.industry || ''} onChange={e => setEditForm({...editForm, industry: e.target.value})} className={inputCls} /></Field>
          <Field label="Email"><input type="email" value={editForm.email || ''} onChange={e => setEditForm({...editForm, email: e.target.value})} className={inputCls} /></Field>
          <Field label="Phone"><input value={editForm.phone || ''} onChange={e => setEditForm({...editForm, phone: e.target.value})} className={inputCls} /></Field>
          <Field label="Tier" span><select value={editForm.subscription_tier || 'starter'} onChange={e => setEditForm({...editForm, subscription_tier: e.target.value})} className={inputCls}><option value="starter">Starter</option><option value="professional">Professional</option><option value="business">Business</option><option value="enterprise">Enterprise</option></select></Field>
          <div className="col-span-2"><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={editForm.is_active ?? true} onChange={e => setEditForm({...editForm, is_active: e.target.checked})} className="rounded border-gray-300 text-primary-600 focus:ring-primary-400/50" /><span className="text-sm text-gray-700">Active</span></label></div>
        </div>
      </Modal>

      {/* Stats Modal */}
      <Modal open={showStatsDialog} onClose={() => setShowStatsDialog(false)} title={(statsClient?.name || '') + ' - Stats'} wide
        footer={<button onClick={() => setShowStatsDialog(false)} className="flex-1 py-2.5 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200 transition-colors">Close</button>}>
        {statsLoading ? <div className="flex items-center justify-center py-8"><RefreshCw className="w-4 h-4 animate-spin text-primary-400" /></div> : stats ? (
          <div className="space-y-4">
            <div className="bg-gray-50 rounded-xl p-4">
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Endpoints</p>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div><p className="text-2xl font-bold text-gray-900">{stats.endpoints.total}</p><p className="text-[10px] text-gray-500">Total</p></div>
                <div><p className="text-2xl font-bold text-healthy">{stats.endpoints.online}</p><p className="text-[10px] text-gray-500">Online</p></div>
                <div><p className="text-2xl font-bold text-critical">{stats.endpoints.offline}</p><p className="text-[10px] text-gray-500">Offline</p></div>
              </div>
              <p className="text-[10px] text-gray-400 mt-2">Limit: {stats.endpoints.limit}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Tickets</p>
                <p className="text-2xl font-bold text-gray-900">{stats.tickets.open}</p><p className="text-[10px] text-gray-500">Open</p>
                <p className="text-lg font-bold text-gray-700 mt-2">{stats.tickets.resolved_30d}</p><p className="text-[10px] text-gray-500">Resolved (30d)</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Microsoft 365</p>
                {stats.m365.connected ? <><div className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-healthy" /><span className="text-xs font-semibold text-healthy">Connected</span></div><p className="text-[10px] text-gray-400 mt-1">{stats.m365.tenant_id?.substring(0, 8)}...</p></> : <span className="text-xs text-gray-400">Not connected</span>}
              </div>
            </div>
          </div>
        ) : <p className="text-xs text-gray-400 text-center py-8">No statistics available</p>}
      </Modal>

      {/* Agent Setup Modal */}
      <Modal open={showAgentSetup} onClose={() => setShowAgentSetup(false)} title={'Agent Setup - ' + (agentSetupClient?.name || '')} wide
        footer={<button onClick={() => setShowAgentSetup(false)} className="flex-1 py-2.5 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200 transition-colors">Close</button>}>
        {agentSetupClient && <AgentSetup clientId={agentSetupClient.id} clientName={agentSetupClient.name} />}
      </Modal>

      {/* Billing Reminder */}
      {showBillingReminder && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setShowBillingReminder(false)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 text-center" onClick={e => e.stopPropagation()}>
            <h2 className="text-base font-bold text-gray-900 mb-1">Client Created!</h2>
            <p className="text-xs text-gray-500 mb-5">Set up billing before your trial ends.</p>
            <button onClick={async () => { try { const r = await api.post('/billing/checkout', { plan: 'starter', success_url: window.location.href + '?billing=success', cancel_url: window.location.href }); if (r.data.url) window.open(r.data.url, '_blank'); } catch {} setShowBillingReminder(false); }} className="w-full py-2.5 bg-opsis-midnight text-white text-sm font-medium rounded-lg hover:bg-gray-800 mb-2 transition-colors">Set Up Billing</button>
            <button onClick={() => setShowBillingReminder(false)} className="w-full py-2.5 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-gray-200 transition-colors">Later</button>
          </div>
        </div>
      )}
    </div>
  );
}
