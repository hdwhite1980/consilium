import { useState, useEffect, useCallback } from 'react';
import { Calendar, Plus, Trash2, Edit3, Clock, Shield, Play, Pause, Monitor, Folder, Globe } from 'lucide-react';
import api from '../services/api';

interface Schedule {
  id: number;
  name: string;
  description: string | null;
  endpoint_id: number | null;
  group_id: number | null;
  days_of_week: number[];
  days_display: string;
  start_time: string;
  end_time: string;
  timezone: string;
  allowed_actions: string[];
  suppress_alerts: boolean;
  allow_reboots: boolean;
  auto_execute_queued: boolean;
  is_active: boolean;
  target: string;
  target_type: string;
  created_at: string;
}

interface Group { id: number; name: string; color: string; }

const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const ACTION_OPTIONS = [
  { value: 'service_restart', label: 'Service Restart' },
  { value: 'process_kill', label: 'Process Kill' },
  { value: 'disk_cleanup', label: 'Disk Cleanup' },
  { value: 'defrag', label: 'Defrag' },
  { value: 'reboot', label: 'Reboot' },
  { value: 'windows_update', label: 'Windows Update' },
  { value: 'config_change', label: 'Config Change' },
  { value: 'network_reset', label: 'Network Reset' },
];

const TIMEZONES = [
  'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
  'America/Phoenix', 'America/Anchorage', 'Pacific/Honolulu', 'UTC',
  'Europe/London', 'Europe/Berlin', 'Asia/Tokyo', 'Australia/Sydney',
];

const defaultForm = {
  name: '', description: '', target_type: 'all' as 'all' | 'group' | 'endpoint',
  endpoint_id: null as number | null, group_id: null as number | null,
  days_of_week: [1, 2, 3, 4, 5], start_time: '02:00', end_time: '06:00',
  timezone: 'America/New_York',
  allowed_actions: ['service_restart', 'process_kill', 'disk_cleanup', 'defrag', 'reboot', 'config_change'],
  suppress_alerts: true, allow_reboots: true, auto_execute_queued: true,
};

export default function MaintenanceSchedules({ clientId }: { clientId: number }) {
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [activeNow, setActiveNow] = useState<any[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [endpoints, setEndpoints] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState(defaultForm);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    try {
      const [sched, active, grp] = await Promise.all([
        api.get(`/clients/${clientId}/maintenance`),
        api.get(`/clients/${clientId}/maintenance/active-now`),
        api.get(`/clients/${clientId}/groups`),
      ]);
      setSchedules(sched.data);
      setActiveNow(active.data);
      setGroups(grp.data);
      try {
        const ep = await api.get(`/clients/${clientId}/endpoints`);
        setEndpoints(ep.data || []);
      } catch {}
    } catch (e) { console.error('Failed to fetch maintenance data', e); }
    finally { setLoading(false); }
  }, [clientId]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const toggleDay = (day: number) => {
    setForm(f => ({
      ...f,
      days_of_week: f.days_of_week.includes(day)
        ? f.days_of_week.filter(d => d !== day)
        : [...f.days_of_week, day].sort(),
    }));
  };

  const toggleAction = (action: string) => {
    setForm(f => ({
      ...f,
      allowed_actions: f.allowed_actions.includes(action)
        ? f.allowed_actions.filter(a => a !== action)
        : [...f.allowed_actions, action],
    }));
  };

  const save = async () => {
    if (!form.name.trim()) return;
    const payload = {
      ...form,
      endpoint_id: form.target_type === 'endpoint' ? form.endpoint_id : null,
      group_id: form.target_type === 'group' ? form.group_id : null,
    };
    try {
      if (editId) {
        await api.put(`/clients/${clientId}/maintenance/${editId}`, payload);
      } else {
        await api.post(`/clients/${clientId}/maintenance`, payload);
      }
      setShowForm(false);
      setEditId(null);
      setForm(defaultForm);
      fetchAll();
    } catch (e: any) { alert(e.response?.data?.detail || 'Failed to save'); }
  };

  const deleteSchedule = async (id: number) => {
    if (!confirm('Delete this maintenance schedule?')) return;
    try {
      await api.delete(`/clients/${clientId}/maintenance/${id}`);
      fetchAll();
    } catch (e) { console.error('Failed to delete', e); }
  };

  const toggleActive = async (s: Schedule) => {
    try {
      await api.put(`/clients/${clientId}/maintenance/${s.id}`, { is_active: !s.is_active });
      fetchAll();
    } catch (e) { console.error('Failed to toggle', e); }
  };

  const startEdit = (s: Schedule) => {
    setEditId(s.id);
    setForm({
      name: s.name, description: s.description || '',
      target_type: s.target_type as any,
      endpoint_id: s.endpoint_id, group_id: s.group_id,
      days_of_week: s.days_of_week, start_time: s.start_time || '02:00',
      end_time: s.end_time || '06:00', timezone: s.timezone,
      allowed_actions: s.allowed_actions,
      suppress_alerts: s.suppress_alerts, allow_reboots: s.allow_reboots,
      auto_execute_queued: s.auto_execute_queued,
    });
    setShowForm(true);
  };

  const targetIcon = (type: string) =>
    type === 'endpoint' ? <Monitor className="w-3 h-3" /> :
    type === 'group' ? <Folder className="w-3 h-3" /> :
    <Globe className="w-3 h-3" />;

  if (loading) return <div className="p-6 text-gray-400">Loading schedules...</div>;

  return (
    <div className="space-y-4">
      {/* Active Now Banner */}
      {activeNow.length > 0 && (
        <div className="p-3 bg-green-50 border border-green-200 rounded-xl">
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-4 h-4 text-healthy" />
            <span className="text-xs font-semibold text-healthy">Maintenance Active Now</span>
          </div>
          {activeNow.map((a, i) => (
            <div key={i} className="text-xs text-green-700 ml-6">
              {a.name} — {a.target} ({a.start_time}–{a.end_time} {a.timezone})
            </div>
          ))}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-[#2DD4FF]" />
          <h3 className="text-sm font-semibold text-gray-900">Maintenance Schedules</h3>
          <span className="text-xs text-gray-500">({schedules.length})</span>
        </div>
        <button onClick={() => { setShowForm(true); setEditId(null); setForm(defaultForm); }}
          className="px-3 py-1.5 text-xs bg-opsis-midnight hover:bg-gray-800 text-white rounded-lg transition-colors flex items-center gap-1">
          <Plus className="w-3 h-3" /> New Schedule
        </button>
      </div>

      {/* Form */}
      {showForm && (
        <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
          <h4 className="text-xs font-semibold text-gray-900">{editId ? 'Edit Schedule' : 'New Maintenance Schedule'}</h4>

          <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            placeholder="Schedule name (e.g. Nightly Maintenance)" className="w-full px-3 py-2 text-sm bg-white border border-gray-200 rounded-lg text-gray-900 placeholder:text-gray-400 outline-none focus:border-[#2DD4FF] focus:ring-2 focus:ring-[#2DD4FF]/20" />

          {/* Target */}
          <div>
            <label className="text-[10px] text-gray-500 block mb-1 font-semibold uppercase tracking-wide">Applies to</label>
            <div className="flex gap-2">
              {(['all', 'group', 'endpoint'] as const).map(t => (
                <button key={t} onClick={() => setForm(f => ({ ...f, target_type: t }))}
                  className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${form.target_type === t ? 'bg-[#2DD4FF]/10 border-[#2DD4FF]/40 text-[#0891b2] font-semibold' : 'bg-white border-gray-200 text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
                  {t === 'all' ? 'All Endpoints' : t === 'group' ? 'Group' : 'Specific Endpoint'}
                </button>
              ))}
            </div>
            {form.target_type === 'group' && (
              <select value={form.group_id || ''} onChange={e => setForm(f => ({ ...f, group_id: Number(e.target.value) }))}
                className="mt-2 w-full px-3 py-2 text-sm bg-white border border-gray-200 rounded-lg text-gray-900 outline-none focus:border-[#2DD4FF]">
                <option value="">Select group...</option>
                {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
              </select>
            )}
            {form.target_type === 'endpoint' && (
              <select value={form.endpoint_id || ''} onChange={e => setForm(f => ({ ...f, endpoint_id: Number(e.target.value) }))}
                className="mt-2 w-full px-3 py-2 text-sm bg-white border border-gray-200 rounded-lg text-gray-900 outline-none focus:border-[#2DD4FF]">
                <option value="">Select endpoint...</option>
                {endpoints.map(ep => <option key={ep.id} value={ep.id}>{ep.hostname}</option>)}
              </select>
            )}
          </div>

          {/* Days */}
          <div>
            <label className="text-[10px] text-gray-500 block mb-1 font-semibold uppercase tracking-wide">Days</label>
            <div className="flex gap-1">
              {DAY_LABELS.map((label, i) => (
                <button key={i} onClick={() => toggleDay(i)}
                  className={`w-9 h-8 text-[10px] font-semibold rounded-md transition-colors ${form.days_of_week.includes(i) ? 'bg-[#2DD4FF]/15 text-[#0891b2] border border-[#2DD4FF]/40' : 'bg-white text-gray-400 border border-gray-200'}`}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Time + TZ */}
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-[10px] text-gray-500 block mb-1 font-semibold uppercase tracking-wide">Start</label>
              <input type="time" value={form.start_time} onChange={e => setForm(f => ({ ...f, start_time: e.target.value }))}
                className="w-full px-2 py-1.5 text-xs bg-white border border-gray-200 rounded-lg text-gray-900 outline-none focus:border-[#2DD4FF]" />
            </div>
            <div>
              <label className="text-[10px] text-gray-500 block mb-1 font-semibold uppercase tracking-wide">End</label>
              <input type="time" value={form.end_time} onChange={e => setForm(f => ({ ...f, end_time: e.target.value }))}
                className="w-full px-2 py-1.5 text-xs bg-white border border-gray-200 rounded-lg text-gray-900 outline-none focus:border-[#2DD4FF]" />
            </div>
            <div>
              <label className="text-[10px] text-gray-500 block mb-1 font-semibold uppercase tracking-wide">Timezone</label>
              <select value={form.timezone} onChange={e => setForm(f => ({ ...f, timezone: e.target.value }))}
                className="w-full px-2 py-1.5 text-xs bg-white border border-gray-200 rounded-lg text-gray-900 outline-none focus:border-[#2DD4FF]">
                {TIMEZONES.map(tz => <option key={tz} value={tz}>{tz.replace('America/', '').replace('_', ' ')}</option>)}
              </select>
            </div>
          </div>

          {/* Allowed Actions */}
          <div>
            <label className="text-[10px] text-gray-500 block mb-1 font-semibold uppercase tracking-wide">Allowed Actions</label>
            <div className="flex flex-wrap gap-1.5">
              {ACTION_OPTIONS.map(a => (
                <button key={a.value} onClick={() => toggleAction(a.value)}
                  className={`px-2 py-1 text-[10px] rounded-md border transition-colors ${form.allowed_actions.includes(a.value) ? 'bg-[#2DD4FF]/10 border-[#2DD4FF]/40 text-[#0891b2] font-semibold' : 'bg-white border-gray-200 text-gray-500 hover:text-gray-700'}`}>
                  {a.label}
                </button>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="flex gap-4">
            {[
              { key: 'allow_reboots', label: 'Allow Reboots' },
              { key: 'suppress_alerts', label: 'Suppress Alerts' },
              { key: 'auto_execute_queued', label: 'Auto-Execute Queued' },
            ].map(({ key, label }) => (
              <label key={key} className="flex items-center gap-1.5 cursor-pointer">
                <input type="checkbox" checked={(form as any)[key]}
                  onChange={() => setForm(f => ({ ...f, [key]: !(f as any)[key] }))}
                  className="rounded border-gray-300 text-[#2DD4FF] focus:ring-[#2DD4FF]/50" />
                <span className="text-[10px] text-gray-700">{label}</span>
              </label>
            ))}
          </div>

          <div className="flex gap-2">
            <button onClick={save} className="px-4 py-1.5 text-xs bg-opsis-midnight text-white rounded-lg font-semibold hover:bg-gray-800">
              {editId ? 'Save' : 'Create'}
            </button>
            <button onClick={() => { setShowForm(false); setEditId(null); }}
              className="px-4 py-1.5 text-xs bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">Cancel</button>
          </div>
        </div>
      )}

      {/* Schedules List */}
      {schedules.length === 0 ? (
        <div className="py-8 text-center">
          <Calendar className="w-8 h-8 mx-auto text-gray-300 mb-2" />
          <p className="text-xs text-gray-500">No maintenance schedules configured.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {schedules.map(s => (
            <div key={s.id} className={`p-3 rounded-xl border transition-colors ${s.is_active ? 'bg-white border-gray-200' : 'bg-gray-50 border-gray-100 opacity-60'}`}>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-gray-400">{targetIcon(s.target_type)}</div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-900 font-medium">{s.name}</span>
                    {!s.is_active && <span className="text-[9px] px-1.5 py-0.5 bg-gray-100 text-gray-500 rounded font-semibold">Paused</span>}
                  </div>
                  <div className="flex items-center gap-3 mt-0.5">
                    <span className="text-[10px] text-gray-500">{s.target}</span>
                    <span className="text-[10px] text-gray-300">•</span>
                    <span className="text-[10px] text-gray-500 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" /> {s.days_display} {s.start_time}–{s.end_time}
                    </span>
                    <span className="text-[10px] text-gray-400">{s.timezone?.replace('America/', '')}</span>
                  </div>
                </div>
                <button onClick={() => toggleActive(s)} className={`p-1.5 rounded ${s.is_active ? 'text-healthy hover:bg-green-50' : 'text-gray-400 hover:bg-gray-100'}`}
                  title={s.is_active ? 'Pause' : 'Resume'}>
                  {s.is_active ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                </button>
                <button onClick={() => startEdit(s)} className="p-1.5 text-gray-400 hover:text-[#2DD4FF] rounded hover:bg-gray-100">
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => deleteSchedule(s.id)} className="p-1.5 text-gray-400 hover:text-critical rounded hover:bg-red-50">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
