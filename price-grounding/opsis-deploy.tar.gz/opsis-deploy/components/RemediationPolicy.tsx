import { useState, useEffect, useCallback } from 'react';
import { Settings, Save, RotateCcw, Shield, Bell, Zap, Server, Monitor, AlertTriangle, Clock } from 'lucide-react';
import api from '../services/api';

interface Policy {
  tenant_id: number;
  is_custom: boolean;
  auto_remediate_threshold: number;
  ticket_only_threshold: number;
  workstation_actions: string[];
  server_actions: string[];
  auto_reboot_allowed: boolean;
  reboot_requires_approval: boolean;
  max_reboots_per_day: number;
  notify_user_before_action: boolean;
  notification_delay_seconds: number;
  notify_on_actions: string[];
  escalate_after_failures: number;
  max_remediations_per_hour: number;
  m365_auto_remediate: boolean;
  m365_allowed_actions: string[];
  severity_overrides: Record<string, any>;
  category_overrides: Record<string, any>;
  allowed_hours_start: string | null;
  allowed_hours_end: string | null;
  allowed_hours_timezone: string;
  is_active: boolean;
  notes: string;
}

const ALL_ACTIONS = [
  { value: 'service_restart', label: 'Service Restart', icon: '🔄' },
  { value: 'process_kill', label: 'Process Kill', icon: '⚡' },
  { value: 'disk_cleanup', label: 'Disk Cleanup', icon: '🧹' },
  { value: 'config_change', label: 'Config Change', icon: '⚙️' },
  { value: 'dns_flush', label: 'DNS Flush', icon: '🌐' },
  { value: 'network_reset', label: 'Network Reset', icon: '📡' },
  { value: 'reboot', label: 'Reboot', icon: '🔁' },
  { value: 'defrag', label: 'Defrag', icon: '💿' },
  { value: 'windows_update', label: 'Windows Update', icon: '📦' },
  { value: 'registry_fix', label: 'Registry Fix', icon: '📝' },
];

const M365_ACTIONS = [
  { value: 'password_reset', label: 'Password Reset' },
  { value: 'license_assign', label: 'License Assign' },
  { value: 'license_remove', label: 'License Remove' },
  { value: 'mfa_reset', label: 'MFA Reset' },
  { value: 'group_add', label: 'Group Add' },
  { value: 'group_remove', label: 'Group Remove' },
  { value: 'block_signin', label: 'Block Sign-in' },
];

const NOTIFY_ACTIONS = [
  'service_restart', 'process_kill', 'reboot', 'network_reset', 'disk_cleanup',
];

export default function RemediationPolicy({ clientId, clientName }: { clientId: number; clientName?: string }) {
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [original, setOriginal] = useState<Policy | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const fetchPolicy = useCallback(async () => {
    try {
      const res = await api.get(`/clients/${clientId}/policy`);
      setPolicy(res.data);
      setOriginal(res.data);
    } catch (e) { console.error('Failed to fetch policy', e); }
    finally { setLoading(false); }
  }, [clientId]);

  useEffect(() => { fetchPolicy(); }, [fetchPolicy]);

  const save = async () => {
    if (!policy) return;
    setSaving(true);
    try {
      await api.put(`/clients/${clientId}/policy`, policy);
      setSaved(true);
      setOriginal(policy);
      setTimeout(() => setSaved(false), 2000);
    } catch (e: any) {
      alert(e.response?.data?.detail || 'Failed to save policy');
    } finally { setSaving(false); }
  };

  const reset = () => {
    if (original) setPolicy({ ...original });
  };

  const hasChanges = JSON.stringify(policy) !== JSON.stringify(original);

  const toggleAction = (field: 'workstation_actions' | 'server_actions' | 'notify_on_actions' | 'm365_allowed_actions', action: string) => {
    if (!policy) return;
    const current = policy[field] || [];
    setPolicy({
      ...policy,
      [field]: current.includes(action)
        ? current.filter((a: string) => a !== action)
        : [...current, action],
    });
  };

  const ActionChips = ({ field, options, current }: {
    field: 'workstation_actions' | 'server_actions' | 'notify_on_actions' | 'm365_allowed_actions';
    options: { value: string; label: string }[];
    current: string[];
  }) => (
    <div className="flex flex-wrap gap-1.5">
      {options.map(a => (
        <button key={a.value} onClick={() => toggleAction(field, a.value)}
          className={`px-2.5 py-1 text-[10px] rounded-md border transition-colors ${current.includes(a.value) ? 'bg-[#2DD4FF]/10 border-[#2DD4FF]/40 text-[#0891b2] font-semibold' : 'bg-gray-50 border-gray-200 text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}>
          {a.label}
        </button>
      ))}
    </div>
  );

  if (loading) return <div className="p-6 text-gray-400">Loading policy...</div>;
  if (!policy) return <div className="p-6 text-critical">Failed to load policy</div>;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#2DD4FF]" />
          <h3 className="text-sm font-semibold text-gray-900">Remediation Policy</h3>
          {clientName && <span className="text-xs text-gray-500">— {clientName}</span>}
          {!policy.is_custom && (
            <span className="text-[9px] px-2 py-0.5 bg-yellow-50 text-yellow-700 rounded-full border border-yellow-200 font-semibold">
              Using Defaults
            </span>
          )}
        </div>
        <div className="flex gap-2">
          {hasChanges && (
            <button onClick={reset}
              className="px-3 py-1.5 text-xs bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center gap-1">
              <RotateCcw className="w-3 h-3" /> Reset
            </button>
          )}
          <button onClick={save} disabled={!hasChanges || saving}
            className={`px-4 py-1.5 text-xs rounded-lg font-semibold flex items-center gap-1 transition-colors ${
              saved ? 'bg-green-50 text-healthy border border-green-200' :
              hasChanges ? 'bg-opsis-midnight text-white hover:bg-gray-800' :
              'bg-gray-100 text-gray-400 cursor-not-allowed'}`}>
            {saved ? '✓ Saved' : <><Save className="w-3 h-3" /> Save Policy</>}
          </button>
        </div>
      </div>

      {/* AI Confidence Thresholds */}
      <Section icon={<Zap className="w-4 h-4 text-[#2DD4FF]" />} title="AI Confidence Thresholds">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-[10px] text-gray-500 mb-1 block font-semibold uppercase tracking-wide">Auto-Remediate Above</label>
            <div className="flex items-center gap-2">
              <input type="range" min="50" max="100" value={policy.auto_remediate_threshold}
                onChange={e => setPolicy({ ...policy, auto_remediate_threshold: Number(e.target.value) })}
                className="flex-1 accent-[#2DD4FF]" />
              <span className="text-sm text-gray-900 font-mono w-10 text-right font-bold">{policy.auto_remediate_threshold}%</span>
            </div>
            <p className="text-[9px] text-gray-400 mt-0.5">Issues above this confidence are auto-fixed</p>
          </div>
          <div>
            <label className="text-[10px] text-gray-500 mb-1 block font-semibold uppercase tracking-wide">Ticket Only Below</label>
            <div className="flex items-center gap-2">
              <input type="range" min="0" max="80" value={policy.ticket_only_threshold}
                onChange={e => setPolicy({ ...policy, ticket_only_threshold: Number(e.target.value) })}
                className="flex-1 accent-yellow-500" />
              <span className="text-sm text-gray-900 font-mono w-10 text-right font-bold">{policy.ticket_only_threshold}%</span>
            </div>
            <p className="text-[9px] text-gray-400 mt-0.5">Issues below this create a ticket, no action taken</p>
          </div>
        </div>
        <div className="mt-3 p-2 bg-gray-50 rounded-lg border border-gray-100">
          <div className="flex items-center gap-1 text-[10px]">
            <span className="text-critical font-semibold">0%</span>
            <div className="flex-1 h-2 rounded-full overflow-hidden flex">
              <div className="bg-yellow-400/60" style={{ width: `${policy.ticket_only_threshold}%` }} />
              <div className="bg-orange-400/60" style={{ width: `${policy.auto_remediate_threshold - policy.ticket_only_threshold}%` }} />
              <div className="bg-healthy/60" style={{ width: `${100 - policy.auto_remediate_threshold}%` }} />
            </div>
            <span className="text-healthy font-semibold">100%</span>
          </div>
          <div className="flex justify-between mt-1 text-[9px] text-gray-400">
            <span>Ticket Only</span>
            <span>Review Required</span>
            <span>Auto-Fix</span>
          </div>
        </div>
      </Section>

      {/* Allowed Actions */}
      <Section icon={<Monitor className="w-4 h-4 text-[#2DD4FF]" />} title="Workstation Actions">
        <ActionChips field="workstation_actions" options={ALL_ACTIONS} current={policy.workstation_actions || []} />
      </Section>

      <Section icon={<Server className="w-4 h-4 text-[#2DD4FF]" />} title="Server Actions">
        <ActionChips field="server_actions" options={ALL_ACTIONS} current={policy.server_actions || []} />
        <p className="text-[9px] text-gray-400 mt-1">Servers have stricter defaults — only safe actions enabled</p>
      </Section>

      {/* Reboot Policy */}
      <Section icon={<AlertTriangle className="w-4 h-4 text-warning" />} title="Reboot Policy">
        <div className="space-y-2">
          <Toggle label="Auto-reboot allowed" checked={policy.auto_reboot_allowed}
            onChange={() => setPolicy({ ...policy, auto_reboot_allowed: !policy.auto_reboot_allowed })} />
          <Toggle label="Reboot requires user approval" checked={policy.reboot_requires_approval}
            onChange={() => setPolicy({ ...policy, reboot_requires_approval: !policy.reboot_requires_approval })} />
          <div className="flex items-center gap-2">
            <label className="text-[10px] text-gray-500">Max reboots per day:</label>
            <input type="number" min="0" max="10" value={policy.max_reboots_per_day}
              onChange={e => setPolicy({ ...policy, max_reboots_per_day: Number(e.target.value) })}
              className="w-14 px-2 py-1 text-xs bg-white border border-gray-200 rounded text-gray-900 text-center outline-none focus:border-[#2DD4FF]" />
          </div>
        </div>
      </Section>

      {/* User Notifications */}
      <Section icon={<Bell className="w-4 h-4 text-[#2DD4FF]" />} title="User Notifications">
        <Toggle label="Notify user before disruptive actions" checked={policy.notify_user_before_action}
          onChange={() => setPolicy({ ...policy, notify_user_before_action: !policy.notify_user_before_action })} />
        {policy.notify_user_before_action && (
          <>
            <div className="flex items-center gap-2 mt-2">
              <label className="text-[10px] text-gray-500">Delay before action (seconds):</label>
              <input type="number" min="0" max="60" value={policy.notification_delay_seconds}
                onChange={e => setPolicy({ ...policy, notification_delay_seconds: Number(e.target.value) })}
                className="w-14 px-2 py-1 text-xs bg-white border border-gray-200 rounded text-gray-900 text-center outline-none focus:border-[#2DD4FF]" />
            </div>
            <div className="mt-2">
              <label className="text-[10px] text-gray-500 block mb-1 font-semibold uppercase tracking-wide">Notify on these actions:</label>
              <ActionChips field="notify_on_actions"
                options={NOTIFY_ACTIONS.map(a => ({ value: a, label: a.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase()) }))}
                current={policy.notify_on_actions || []} />
            </div>
          </>
        )}
      </Section>

      {/* Rate Limits */}
      <Section icon={<Clock className="w-4 h-4 text-[#2DD4FF]" />} title="Rate Limits & Escalation">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-[10px] text-gray-500 mb-1 block font-semibold uppercase tracking-wide">Max remediations per hour</label>
            <input type="number" min="1" max="100" value={policy.max_remediations_per_hour}
              onChange={e => setPolicy({ ...policy, max_remediations_per_hour: Number(e.target.value) })}
              className="w-full px-3 py-1.5 text-sm bg-white border border-gray-200 rounded-lg text-gray-900 outline-none focus:border-[#2DD4FF]" />
          </div>
          <div>
            <label className="text-[10px] text-gray-500 mb-1 block font-semibold uppercase tracking-wide">Escalate after N failures</label>
            <input type="number" min="1" max="10" value={policy.escalate_after_failures}
              onChange={e => setPolicy({ ...policy, escalate_after_failures: Number(e.target.value) })}
              className="w-full px-3 py-1.5 text-sm bg-white border border-gray-200 rounded-lg text-gray-900 outline-none focus:border-[#2DD4FF]" />
          </div>
        </div>
      </Section>

      {/* M365 Policy */}
      <Section icon={<Shield className="w-4 h-4 text-blue-500" />} title="Microsoft 365 Policy">
        <Toggle label="Auto-remediate M365 issues" checked={policy.m365_auto_remediate}
          onChange={() => setPolicy({ ...policy, m365_auto_remediate: !policy.m365_auto_remediate })} />
        <div className="mt-2">
          <label className="text-[10px] text-gray-500 block mb-1 font-semibold uppercase tracking-wide">Allowed M365 actions:</label>
          <ActionChips field="m365_allowed_actions" options={M365_ACTIONS} current={policy.m365_allowed_actions || []} />
        </div>
      </Section>

      {/* Notes */}
      <Section icon={<Settings className="w-4 h-4 text-gray-400" />} title="Notes">
        <textarea value={policy.notes || ''} onChange={e => setPolicy({ ...policy, notes: e.target.value })}
          placeholder="Internal notes about this client's policy preferences..."
          className="w-full px-3 py-2 text-xs bg-white border border-gray-200 rounded-lg text-gray-900 placeholder:text-gray-400 outline-none focus:border-[#2DD4FF] focus:ring-2 focus:ring-[#2DD4FF]/20 resize-none h-20" />
      </Section>
    </div>
  );
}

// Helper components
function Section({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="p-4 bg-gray-50 rounded-xl border border-gray-200">
      <div className="flex items-center gap-2 mb-3">
        {icon}
        <h4 className="text-xs font-semibold text-gray-900">{title}</h4>
      </div>
      {children}
    </div>
  );
}

function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex items-center gap-2 cursor-pointer">
      <div onClick={onChange}
        className={`w-8 h-4.5 rounded-full p-0.5 transition-colors ${checked ? 'bg-[#2DD4FF]' : 'bg-gray-300'}`}>
        <div className={`w-3.5 h-3.5 bg-white rounded-full shadow transition-transform ${checked ? 'translate-x-3.5' : 'translate-x-0'}`} />
      </div>
      <span className="text-[11px] text-gray-700">{label}</span>
    </label>
  );
}
