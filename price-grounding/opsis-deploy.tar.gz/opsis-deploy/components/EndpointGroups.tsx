import { useState, useEffect, useCallback } from 'react';
import { Folder, Plus, Trash2, Edit3, Users, Monitor, ChevronDown, ChevronRight, Check, X, Palette, Search } from 'lucide-react';
import api from '../services/api';

interface Group {
  id: number;
  name: string;
  description: string | null;
  color: string;
  icon: string;
  member_count: number;
  created_at: string;
}

interface Endpoint {
  id: number;
  hostname: string;
  device_id: string;
  status: string;
  endpoint_type: string;
  operating_system: string;
  agent_version: string;
  last_seen: string | null;
  ip_address: string | null;
}

const PRESET_COLORS = [
  '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6',
  '#EC4899', '#06B6D4', '#F97316', '#14B8A6', '#6366F1',
];

export default function EndpointGroups({ clientId }: { clientId: number }) {
  const [groups, setGroups] = useState<Group[]>([]);
  const [endpoints, setEndpoints] = useState<Endpoint[]>([]);
  const [expandedGroup, setExpandedGroup] = useState<number | null>(null);
  const [groupMembers, setGroupMembers] = useState<Endpoint[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [editGroup, setEditGroup] = useState<Group | null>(null);
  const [showBulkAssign, setShowBulkAssign] = useState(false);
  const [selectedEndpoints, setSelectedEndpoints] = useState<number[]>([]);
  const [bulkTargetGroup, setBulkTargetGroup] = useState<number | null>(null);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: '', description: '', color: '#3B82F6' });

  const fetchGroups = useCallback(async () => {
    try {
      const res = await api.get(`/clients/${clientId}/groups`);
      setGroups(res.data);
    } catch (e) { console.error('Failed to fetch groups', e); }
  }, [clientId]);

  const fetchEndpoints = useCallback(async () => {
    try {
      const res = await api.get(`/clients/${clientId}/endpoints`);
      setEndpoints(res.data || []);
    } catch (e) { console.error('Failed to fetch endpoints', e); }
  }, [clientId]);

  useEffect(() => {
    Promise.all([fetchGroups(), fetchEndpoints()]).finally(() => setLoading(false));
  }, [fetchGroups, fetchEndpoints]);

  const fetchMembers = async (groupId: number) => {
    try {
      const res = await api.get(`/clients/${clientId}/groups/${groupId}/members`);
      setGroupMembers(res.data);
    } catch (e) { console.error('Failed to fetch members', e); }
  };

  const toggleExpand = (groupId: number) => {
    if (expandedGroup === groupId) {
      setExpandedGroup(null);
      setGroupMembers([]);
    } else {
      setExpandedGroup(groupId);
      fetchMembers(groupId);
    }
  };

  const createGroup = async () => {
    if (!form.name.trim()) return;
    try {
      await api.post(`/clients/${clientId}/groups`, form);
      setShowCreate(false);
      setForm({ name: '', description: '', color: '#3B82F6' });
      fetchGroups();
    } catch (e: any) {
      alert(e.response?.data?.detail || 'Failed to create group');
    }
  };

  const updateGroup = async () => {
    if (!editGroup) return;
    try {
      await api.put(`/clients/${clientId}/groups/${editGroup.id}`, {
        name: form.name, description: form.description, color: form.color,
      });
      setEditGroup(null);
      fetchGroups();
    } catch (e: any) {
      alert(e.response?.data?.detail || 'Failed to update group');
    }
  };

  const deleteGroup = async (groupId: number) => {
    if (!confirm('Delete this group? Endpoints will not be deleted.')) return;
    try {
      await api.delete(`/clients/${clientId}/groups/${groupId}`);
      if (expandedGroup === groupId) setExpandedGroup(null);
      fetchGroups();
    } catch (e) { console.error('Failed to delete group', e); }
  };

  const removeFromGroup = async (groupId: number, endpointId: number) => {
    try {
      await api.delete(`/clients/${clientId}/groups/${groupId}/members`, {
        data: { endpoint_ids: [endpointId] },
      });
      fetchMembers(groupId);
      fetchGroups();
    } catch (e) { console.error('Failed to remove member', e); }
  };

  const bulkAssign = async () => {
    if (!bulkTargetGroup || selectedEndpoints.length === 0) return;
    try {
      await api.post(`/clients/${clientId}/groups/bulk-assign`, {
        group_id: bulkTargetGroup,
        endpoint_ids: selectedEndpoints,
      });
      setShowBulkAssign(false);
      setSelectedEndpoints([]);
      setBulkTargetGroup(null);
      fetchGroups();
    } catch (e) { console.error('Bulk assign failed', e); }
  };

  const toggleEndpoint = (id: number) => {
    setSelectedEndpoints(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const filteredEndpoints = endpoints.filter(e =>
    e.hostname.toLowerCase().includes(search.toLowerCase()) ||
    (e.ip_address || '').includes(search)
  );

  const statusColor = (s: string) =>
    s === 'ONLINE' ? 'text-healthy' : s === 'OFFLINE' ? 'text-critical' : 'text-warning';

  if (loading) return <div className="p-6 text-gray-400">Loading groups...</div>;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Folder className="w-5 h-5 text-[#2DD4FF]" />
          <h3 className="text-sm font-semibold text-gray-900">Endpoint Groups</h3>
          <span className="text-xs text-gray-500">({groups.length})</span>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowBulkAssign(true)}
            className="px-3 py-1.5 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg border border-gray-200 transition-colors flex items-center gap-1">
            <Users className="w-3 h-3" /> Bulk Assign
          </button>
          <button onClick={() => { setShowCreate(true); setForm({ name: '', description: '', color: '#3B82F6' }); }}
            className="px-3 py-1.5 text-xs bg-opsis-midnight hover:bg-gray-800 text-white rounded-lg transition-colors flex items-center gap-1">
            <Plus className="w-3 h-3" /> New Group
          </button>
        </div>
      </div>

      {/* Create / Edit Form */}
      {(showCreate || editGroup) && (
        <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
          <h4 className="text-xs font-semibold text-gray-900">{editGroup ? 'Edit Group' : 'Create Group'}</h4>
          <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            placeholder="Group name (e.g. Accounting)" className="w-full px-3 py-2 text-sm bg-white border border-gray-200 rounded-lg text-gray-900 placeholder:text-gray-400 focus:border-[#2DD4FF] focus:ring-2 focus:ring-[#2DD4FF]/20 outline-none" />
          <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
            placeholder="Description (optional)" className="w-full px-3 py-2 text-sm bg-white border border-gray-200 rounded-lg text-gray-900 placeholder:text-gray-400 focus:border-[#2DD4FF] focus:ring-2 focus:ring-[#2DD4FF]/20 outline-none" />
          <div className="flex items-center gap-2">
            <Palette className="w-3 h-3 text-gray-400" />
            <span className="text-xs text-gray-500">Color:</span>
            {PRESET_COLORS.map(c => (
              <button key={c} onClick={() => setForm(f => ({ ...f, color: c }))}
                className={`w-5 h-5 rounded-full border-2 transition-all ${form.color === c ? 'border-gray-900 scale-110' : 'border-transparent'}`}
                style={{ backgroundColor: c }} />
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={editGroup ? updateGroup : createGroup}
              className="px-4 py-1.5 text-xs bg-opsis-midnight text-white rounded-lg font-semibold hover:bg-gray-800">
              {editGroup ? 'Save' : 'Create'}
            </button>
            <button onClick={() => { setShowCreate(false); setEditGroup(null); }}
              className="px-4 py-1.5 text-xs bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">Cancel</button>
          </div>
        </div>
      )}

      {/* Bulk Assign */}
      {showBulkAssign && (
        <div className="p-4 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
          <h4 className="text-xs font-semibold text-gray-900">Bulk Assign Endpoints to Group</h4>
          <select value={bulkTargetGroup || ''} onChange={e => setBulkTargetGroup(Number(e.target.value))}
            className="w-full px-3 py-2 text-sm bg-white border border-gray-200 rounded-lg text-gray-900 outline-none focus:border-[#2DD4FF]">
            <option value="">Select group...</option>
            {groups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
          <div className="flex items-center gap-2">
            <Search className="w-3 h-3 text-gray-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search endpoints..."
              className="flex-1 px-3 py-1.5 text-xs bg-white border border-gray-200 rounded-lg text-gray-900 placeholder:text-gray-400 outline-none focus:border-[#2DD4FF]" />
          </div>
          <div className="max-h-48 overflow-y-auto space-y-1">
            {filteredEndpoints.map(ep => (
              <label key={ep.id} className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-gray-100 cursor-pointer">
                <input type="checkbox" checked={selectedEndpoints.includes(ep.id)}
                  onChange={() => toggleEndpoint(ep.id)} className="rounded border-gray-300 text-[#2DD4FF] focus:ring-[#2DD4FF]/50" />
                <Monitor className="w-3 h-3 text-gray-400" />
                <span className="text-xs text-gray-900 flex-1">{ep.hostname}</span>
                <span className={`text-[10px] ${statusColor(ep.status)}`}>{ep.status}</span>
              </label>
            ))}
          </div>
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-gray-500">{selectedEndpoints.length} selected</span>
            <div className="flex gap-2">
              <button onClick={bulkAssign} disabled={!bulkTargetGroup || selectedEndpoints.length === 0}
                className="px-4 py-1.5 text-xs bg-opsis-midnight text-white rounded-lg font-semibold hover:bg-gray-800 disabled:opacity-30">
                Assign {selectedEndpoints.length}
              </button>
              <button onClick={() => { setShowBulkAssign(false); setSelectedEndpoints([]); }}
                className="px-4 py-1.5 text-xs bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Groups List */}
      {groups.length === 0 ? (
        <div className="py-8 text-center">
          <Folder className="w-8 h-8 mx-auto text-gray-300 mb-2" />
          <p className="text-xs text-gray-500">No groups yet. Create one to organize your endpoints.</p>
        </div>
      ) : (
        <div className="space-y-1">
          {groups.map(g => (
            <div key={g.id} className="border border-gray-200 rounded-lg overflow-hidden">
              <div className="flex items-center gap-3 px-3 py-2.5 hover:bg-gray-50 cursor-pointer"
                onClick={() => toggleExpand(g.id)}>
                {expandedGroup === g.id ? <ChevronDown className="w-3 h-3 text-gray-400" /> : <ChevronRight className="w-3 h-3 text-gray-400" />}
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: g.color }} />
                <span className="text-sm text-gray-900 font-medium flex-1">{g.name}</span>
                <span className="text-[10px] text-gray-500">{g.member_count} endpoint{g.member_count !== 1 ? 's' : ''}</span>
                <button onClick={e => { e.stopPropagation(); setEditGroup(g); setForm({ name: g.name, description: g.description || '', color: g.color }); }}
                  className="p-1 text-gray-400 hover:text-[#2DD4FF] rounded"><Edit3 className="w-3 h-3" /></button>
                <button onClick={e => { e.stopPropagation(); deleteGroup(g.id); }}
                  className="p-1 text-gray-400 hover:text-critical rounded"><Trash2 className="w-3 h-3" /></button>
              </div>
              {expandedGroup === g.id && (
                <div className="border-t border-gray-100 bg-gray-50/50">
                  {groupMembers.length === 0 ? (
                    <p className="px-4 py-3 text-xs text-gray-500">No endpoints in this group.</p>
                  ) : (
                    groupMembers.map(ep => (
                      <div key={ep.id} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100">
                        <Monitor className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-900 flex-1">{ep.hostname}</span>
                        <span className="text-[10px] text-gray-500">{ep.ip_address}</span>
                        <span className={`text-[10px] ${statusColor(ep.status)}`}>●</span>
                        <button onClick={() => removeFromGroup(g.id, ep.id)}
                          className="p-1 text-gray-300 hover:text-critical"><X className="w-3 h-3" /></button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
